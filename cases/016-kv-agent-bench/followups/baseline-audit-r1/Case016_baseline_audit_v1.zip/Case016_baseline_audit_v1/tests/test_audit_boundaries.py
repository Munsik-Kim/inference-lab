"""SYNTHETIC_CONTRACT_TEST: injected generator, no model/network."""
import asyncio,copy,json,pathlib,sys,tempfile,types,unittest
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'evidence/source')]
from kv_agent_bench.fixture_generator import make_tasks,short_messages,tools,oracle
from kv_agent_bench.common import digest
from kv_agent_bench.tokenization import render,token_hash
import kv_agent_bench.episode_runner as runner
from kv_agent_bench.scorer import assess
from audit_baseline import assemble

class ByteTokenizer:
 def apply_chat_template(self,messages,**kw):return json.dumps({'messages':messages,'tools':kw.get('tools')},sort_keys=True)
 def encode(self,text,**kw):return list(text.encode())
 def decode(self,ids,**kw):return bytes(ids).decode()

class AuditBoundaries(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.task=make_tasks('AUDIT_SYNTHETIC',1,6101920)[0];self.g=oracle(self.task);self.tok=ByteTokenizer();m=short_messages(self.task);ts=tools(8)
  self.prepared={'messages':m,'tools':ts,'menu':8,'input_token_sha256':token_hash(self.tok.encode(render(self.tok,m,ts))),'surface_hash':digest({'messages':m,'tools':ts})}
  self.cfg={'max_model_calls':8,'max_tool_attempts':6,'episode_token_budget':8192,'request_seconds':180,'episode_seconds':900,'max_model_len':24576,'eos_token_ids':[]};self.calls=0
 def args(self,n):
  return {'read_source':{'source_id':self.g['source_id']},'calculate_amount':{k:self.g[k]for k in ('quantity','unit_price_minor','discount_percent')},'update_state':{k:self.g[k]for k in ('record_id','total_minor','source_version','status')},'validate_state':{'record_id':self.g['record_id']},'service_status':{}}[n]
 def response(self,*names,args=None,malformed=False):
  calls=[];raw=''
  for i,n in enumerate(names):
   a=self.args(n)if args is None else args[i];obj={'name':n,'arguments':a};raw+='<tool_call>'+json.dumps(obj)+'</tool_call>';calls.append({'id':f'call_{self.calls}_{i}','type':'function','function':{'name':n,'arguments':json.dumps(a)}});self.calls+=1
  if malformed:raw+='<tool_call>{bad}</tool_call>'
  return(raw,'',calls)
 def final(self,override=None):
  x={k:self.g[k]for k in ('record_id','total_minor','source_version','status')};x['validated']=True
  if override:x.update(override)
  s=json.dumps(x);return(s,s,[])
 def execute(self,script,config=None,request_error=None):
  ix=iter(script);number=0
  async def request(base,payload,timeout):
   nonlocal number
   number+=1
   if request_error:raise request_error
   raw,content,calls=next(ix);ids=self.tok.encode(render(self.tok,payload['messages'],payload['tools']));out=self.tok.encode(raw)
   return {'content':content,'tool_calls':calls,'output_token_ids':out,'prompt_token_ids':ids,'usage':{'completion_tokens':len(out),'prompt_tokens':len(ids)},'server_finish_reason':'stop','server_stop_reason':None,'raw_sse_lines':[]}
  root=pathlib.Path(self.tmp.name)/f'fixture{len(list(pathlib.Path(self.tmp.name).iterdir()))}'
  e=asyncio.run(runner.run_episode(self.task,self.prepared,self.tok,'http://forbidden', 'B16',1024,root,config or self.cfg,'SYNTHETIC_CONTRACT_TEST',request=request));e['evidence_kind']='SYNTHETIC_CONTRACT_TEST';return e
 def normal(self):return[self.response(n)for n in ('read_source','calculate_amount','update_state','validate_state')]+[self.final()]
 def test_four_calls_five_generations_complete(self):
  e=self.execute(self.normal());self.assertTrue(e['VERIFIED_WORKFLOW_SUCCESS']);self.assertEqual((e['model_calls'],e['tool_attempts']),(5,4))
 def test_sixth_validation_allows_final_without_seventh_tool(self):
  s=[self.response('service_status','service_status')]+self.normal();e=self.execute(s);self.assertTrue(e['VERIFIED_WORKFLOW_SUCCESS']);self.assertEqual((e['model_calls'],e['tool_attempts']),(6,6));self.assertEqual(e['events'][-1]['name'],'validate_state')
 def test_seventh_call_unexecuted_raw_retained(self):
  s=[self.response('service_status','service_status')]+[self.response(n)for n in ('read_source','calculate_amount','update_state','validate_state')]+[self.response('service_status')];e=self.execute(s);self.assertEqual(e['terminal_reason'],'TOOL_CALL_LIMIT');self.assertEqual(len(e['events']),6);self.assertIn('service_status',e['responses'][-1]['raw_text']);self.assertIsNone(e['final'])
 def test_write_validate_one_remaining_slot_stops_before_validation(self):
  s=[self.response('service_status','service_status','service_status'),self.response('read_source'),self.response('calculate_amount'),self.response('update_state','validate_state')];e=self.execute(s);self.assertEqual(e['terminal_reason'],'TOOL_CALL_LIMIT');self.assertTrue(e['STATE_CORRECT']);self.assertEqual(e['events'][-1]['name'],'update_state');self.assertEqual(e['tool_attempts'],6)
 def test_write_validate_two_remaining_slots_allows_final(self):
  s=[self.response('service_status','service_status'),self.response('read_source'),self.response('calculate_amount'),self.response('update_state','validate_state'),self.final()];e=self.execute(s);self.assertTrue(e['VERIFIED_WORKFLOW_SUCCESS']);self.assertEqual(e['tool_attempts'],6)
 def test_rejected_name_schema_and_malformed_consumption(self):
  bad='<tool_call>{"name":"unknown","arguments":{}}</tool_call>';call={'id':'x','type':'function','function':{'name':'unknown','arguments':'{}'}}
  e=self.execute([(bad,'',[call]),self.response('calculate_amount',args=[{'quantity':True,'unit_price_minor':1,'discount_percent':0}]),self.response(malformed=True)]);self.assertEqual(e['tool_attempts'],3);self.assertEqual(len(e['events']),2);self.assertEqual([x['error']for x in e['events']],['UNKNOWN_TOOL','BAD_ARGUMENT_TYPE']);self.assertEqual(e['terminal_reason'],'PARSE_STOP')
 def test_model_request_limit(self):
  cfg={**self.cfg,'max_model_calls':1};e=self.execute([self.response('service_status')],cfg);self.assertEqual(e['terminal_reason'],'MODEL_CALL_LIMIT')
 def test_output_token_limit_before_next_request(self):
  r=self.response('service_status');cfg={**self.cfg,'episode_token_budget':len(self.tok.encode(r[0]))};e=self.execute([r],cfg);self.assertEqual(e['terminal_reason'],'TOKEN_LIMIT');self.assertEqual(e['model_calls'],1)
 def test_context_limit_before_any_request(self):
  cfg={**self.cfg,'max_model_len':1};e=self.execute([],cfg);self.assertEqual(e['terminal_reason'],'CONTEXT_LIMIT');self.assertEqual(e['model_calls'],0)
 def test_deadline_before_any_request(self):
  clock=iter([0,2,2]);fake=types.SimpleNamespace(monotonic=lambda:next(clock));cfg={**self.cfg,'episode_seconds':1}
  with patch.object(runner,'time',fake):e=self.execute([],cfg)
  self.assertEqual(e['terminal_reason'],'EPISODE_DEADLINE');self.assertEqual(e['model_calls'],0)
 def test_request_timeout_distinct(self):
  e=self.execute([],request_error=TimeoutError('scripted timeout'));self.assertEqual(e['terminal_reason'],'REQUEST_TIMEOUT');self.assertEqual(e['model_calls'],0)
 def test_same_response_calls_do_not_gain_prior_result(self):
  s=[self.response('read_source','calculate_amount'),self.response('update_state','validate_state'),self.final()];e=self.execute(s);self.assertTrue(e['STATE_CORRECT']);self.assertTrue(e['FINAL_ANSWER_CORRECT']);self.assertFalse(e['VERIFIED_WORKFLOW_SUCCESS']);self.assertEqual(e['events'][1]['generated_after_event_ids'],[])
 def test_strict_final_bool_extra_key_nested_and_prose(self):
  for variant in ['boolint','extra','nested','prose']:
   s=self.normal();raw,content,calls=s[-1];x=json.loads(content)
   if variant=='boolint':x['validated']=1
   if variant=='extra':x['extra']='ignored?'
   if variant=='nested':x={'answer':x}
   content=('Answer: 'if variant=='prose'else'')+json.dumps(x);s[-1]=(content,content,[]);e=self.execute(s);self.assertFalse(e['FINAL_ANSWER_CORRECT']);self.assertFalse(e['VERIFIED_WORKFLOW_SUCCESS'])
 def test_choice_aware_assembler_rejects_multiple_choices(self):
  lines=['data: '+json.dumps({'choices':[{'index':0,'delta':{'content':'a'}},{'index':1,'delta':{'content':'b'}}]})]
  with self.assertRaises(AssertionError):assemble(lines)
 def test_final_only_never_passes_workflow(self):
  e=self.execute([self.final()]);self.assertTrue(e['FINAL_ANSWER_CORRECT']);self.assertFalse(e['VERIFIED_WORKFLOW_SUCCESS']);self.assertEqual(len(e['events']),0)
if __name__=='__main__':unittest.main()
