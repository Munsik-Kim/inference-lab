"""Lossless, deduplicated P1-only evidence selection. No EVAL data is opened."""
import argparse,copy,hashlib,json,pathlib,shutil,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
def dump(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def digest(x):return hashlib.sha256(dump(x).encode()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def main():
 p=argparse.ArgumentParser();p.add_argument('--case',type=pathlib.Path,required=True);a=p.parse_args();case=a.case.resolve()
 out=ROOT/'evidence';out.mkdir(exist_ok=True);sources=out/'source/kv_agent_bench';sources.mkdir(parents=True,exist_ok=True)
 manifest=[]
 def copy(rel,dest=None):
  f=case/rel;b=f.read_bytes();d=out/(dest or rel);d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
  manifest.append({'original_path':rel,'retained_path':str(d.relative_to(ROOT)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'transformation':'BYTE_IDENTICAL'})
 for name in ['__init__','common','fixture_generator','tools','observations','scorer','audit','vllm_client','tokenization','episode_runner','metrics','cli']:
  copy('src/kv_agent_bench/'+name+'.py','source/kv_agent_bench/'+name+'.py')
 for name in ['server_manager','workload_runner','worker_inspection','kernel_check','p0_diagnostics']:
  copy('src/kv_agent_bench/'+name+'.py','source_static/'+name+'.py')
 for rel in ['REPORT.ko.md','REPRODUCE.ko.md','PLAN.ko.txt','NOTICE.md','REUSE_MAP.md','specs/protocol.json','specs/p1.frozen.json']+[f'specs/amendment{i:02}.json'for i in range(1,9)]:copy(rel)
 for rel in ['code_freeze.json','configuration_frozen.json','B16_attempt00.json','F4_attempt00.json','summary.json','planned_cells.json','diagnostics.json','decision.json']:
  copy('results/p1_r1/'+rel)
 for name in ['test_contracts.py','test_runner_boundaries.py']:copy('tests/'+name)
 copy('publication/tests/test_evidence_properties.py')
 copy('provenance/model_identity.json');copy('provenance/environment.json')
 freezes=json.loads((case/'provenance/execution_source_map.json').read_text());amend=[]
 import difflib
 for s in freezes['frozen_sets']:
  rel=s['freeze'];copy(rel)
  for f in s['files']:
   if f['path'].startswith('src/'):
    content=(case/f['retained_path']).read_bytes()
    assert hashlib.sha256(content).hexdigest()==f['sha256']
    target=out/'historical_sources'/(f['sha256']+'.py')
    if not target.exists():target.parent.mkdir(exist_ok=True);target.write_bytes(content)
    new=(case/f['path']).read_text()
    diff=''.join(difflib.unified_diff(content.decode().splitlines(True),new.splitlines(True),fromfile=rel+':'+f['path'],tofile='P1_FROZEN:'+f['path']))
    if diff:
     d=out/'diffs'/(rel.replace('/','_')+'__'+pathlib.Path(f['path']).name+'.diff');d.parent.mkdir(exist_ok=True);d.write_text(diff)
  amend.append({'freeze':rel,'source_sha256':s['original_source_sha256'],'files':len(s['files']),'created_utc':json.loads((case/rel).read_text()).get('created_utc')})
 save(out/'freeze_timeline.json',amend)
 sys.path.insert(0,str(out/'source'));from kv_agent_bench.fixture_generator import make_tasks,tools
 tasks=make_tasks('DEV',3,6101901);lookup={t['task_id']:t for t in tasks};save(out/'dev_tasks.json',tasks)
 objects={};tokens={};base_tokens={};episodes=[];pointers=[]
 def obj(x):
  key=digest(x);objects.setdefault(key,x);return key
 def tok(ids,parent=None):
  key=digest(ids)
  if key not in tokens:
   if parent and parent in tokens:
    full=expand(parent);n=0
    while n<min(len(full),len(ids)) and full[n]==ids[n]:n+=1
    tokens[key]={'parent':parent,'prefix':n,'suffix':ids[n:]}
   else:tokens[key]={'parent':None,'prefix':0,'suffix':ids}
  return key
 def expand(key):
  r=tokens[key];return (expand(r['parent'])[:r['prefix']]if r['parent']else[])+r['suffix']
 for f in sorted((case/'results/p1_r1/episodes').glob('*.json')):
  raw=f.read_bytes();e=json.loads(raw);t=lookup[e['task_id']];assert e['split']=='DEV' and t['canonical_task_hash']==e['canonical_task_hash']
  new=copy.deepcopy(e);new['responses']=[];base_key=(e['task_id'],e['menu'])
  for i,r in enumerate(e['responses']):
   q={k:v for k,v in r.items()if k not in ('messages','input_token_ids','prompt_token_ids','sse_events','raw_sse_lines')}
   q['messages_ref']=obj(r['messages']);q['input_ids_ref']=tok(r['input_token_ids'],base_tokens.get(base_key));q['prompt_ids_ref']=tok(r['prompt_token_ids'],base_tokens.get(base_key))
   if i==0:base_tokens[base_key]=q['prompt_ids_ref']
   q['raw_sse_sha256']=digest(r['raw_sse_lines']);q['source_pointer']={'path':str(f.relative_to(case)),'file_sha256':hashlib.sha256(raw).hexdigest(),'json_path':f'$.responses[{i}]','excerpt_sha256':digest(r)}
   new['responses'].append(q)
  new['source_pointer']={'path':str(f.relative_to(case)),'file_sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'json_path':'$'}
  episodes.append(new);pointers.append(new['source_pointer'])
 save(out/'objects.json',objects);save(out/'token_sequences.json',tokens);save(out/'episodes.compact.json',episodes)
 save(ROOT/'provenance/source_manifest.json',{'files':manifest,'episode_files':pointers,'dev_reconstruction':'Only make_tasks(DEV,3,6101901); canonical task hashes checked against all96 P1 records. EVAL tasks/token manifests not decoded or selected.','source_sha256':json.loads((case/'results/p1_r1/code_freeze.json').read_text())['source_sha256']})
 print(json.dumps({'episodes':len(episodes),'dev_tasks':len(tasks),'objects':len(objects),'token_sequences':len(tokens),'original_source_files':len(manifest),'new_gpu_requests':0}))
if __name__=='__main__':main()
