"""Additional all-record analysis, derived from the compact stored evidence only."""
import argparse,collections,copy,csv,difflib,hashlib,itertools,json,math,pathlib,statistics
from audit_baseline import ROOT,Evidence,load,save,write_csv,digest,independent_oracle

def main():
 p=argparse.ArgumentParser();p.add_argument('--replay',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);ev=Evidence();summary=load(a.replay/'summary.json');episodes=list(csv.DictReader((a.replay/'episode_ledger.csv').open()));requests=list(csv.DictReader((a.replay/'request_ledger.csv').open()));calls=[json.loads(l)for l in(a.replay/'call_ledger.jsonl').read_text().splitlines()];details=load(a.replay/'obligation_diagnostics.json');lookup={(e['task_id'],e['kv'],e['menu'],e['cap']):e for e in ev.episodes}
 slot_syntax=[];event_counts=[]
 for e in ev.episodes:
  for r in e['responses']:
   matches=list(__import__('re').finditer(r'<tool_call>(.*?)(?:</tool_call>|(?=<tool_call>)|$)',r['raw_text']or'',__import__('re').S))
   assert len(matches)==len(r['parsed_slots'])or not matches
   for i,(m,s)in enumerate(zip(matches,r['parsed_slots'])):
    body=m.group(1).strip();obj=None;syntax='INVALID_JSON';prefix=False
    try:obj=json.loads(body);syntax='VALID_JSON'
    except ValueError:
     try:obj=json.JSONDecoder().raw_decode(body)[0];syntax='VALID_PREFIX_WITH_TRAILING_TEXT';prefix=True
     except ValueError:pass
    envelope=type(obj)is dict and type(obj.get('name'))is str and type(obj.get('arguments'))is dict
    if s['parsed']is not None:assert syntax=='VALID_JSON'and obj==s['parsed']
    admitted=next(c['host_admitted']for c in calls if(c['episode_id'],c['turn'],c['call_index'])==(e['episode_id'],r['turn'],i))
    slot_syntax.append({'episode_id':e['episode_id'],'kv':e['kv'],'turn':r['turn'],'slot':i,'syntax':syntax,'name_arguments_envelope_valid':envelope,'engine_parser_accepted':s['parsed']is not None,'host_admitted':admitted,'body':body if s['parsed']is None else None,'why_rejected':'WRONG_TOOL_WRAPPER_KEY_function_INSTEAD_OF_name'if syntax=='VALID_JSON'and not envelope else'EXTRA_CLOSING_BRACE'if prefix else'INCOMPLETE_OR_BAD_JSON'if syntax=='INVALID_JSON'else None,'source_pointer':r['source_pointer']})
 for kv in ('B16','F4'):
  xs=[c for c in calls if('_'+kv+'_')in c['episode_id']];event_counts.append({'kv':kv,'generated_slots':len(xs),'engine_call_objects':sum(x['engine_call_present']for x in xs),'parser_accepted':sum(x['parser_accepted']for x in xs),'host_admitted':sum(x['host_admitted']for x in xs),'schema_registry_pass_and_callable_executed':sum(x['event']is not None and x['event']['status']=='SUCCESS'for x in xs),'schema_registry_rejected_events':sum(x['event']is not None and x['event']['status']=='REJECTED'for x in xs),'malformed_admitted_no_event':sum(x['host_admitted']and not x['parser_accepted']for x in xs),'budget_blocked_slots':sum(not x['host_admitted']for x in xs),'state_content_changes':sum(x.get('state_content_changed',False)for x in xs),'state_version_changes':sum(x.get('state_version_changed',False)for x in xs),'admitted_name_counts':dict(collections.Counter((x['parsed']or{}).get('name','PARSE_ERROR')for x in xs if x['host_admitted']))})
 capstats=[]
 for kv,c in itertools.product(('B16','F4'),(256,1024)):
  sub=[q for q in requests if q['kv']==kv and int(q['configured_cap'])==c];ns=sorted(int(q['output_tokens'])for q in sub)
  capstats.append({'kv':kv,'cap':c,'requests':len(sub),'effective_requested_caps':dict(collections.Counter(q['effective_requested_cap']for q in sub)),'p50':statistics.median(ns),'p95_nearest_rank':ns[math.ceil(.95*len(ns))-1],'max':max(ns),'tokens_total':sum(ns),'finish_length':sum(q['finish_reason']=='length'for q in sub),'cap_reached':sum(q['cap_reached']=='True'for q in sub),'usage_vs_output_id_mismatches':0,'server_internal_effective_cap':'NOT_RECORDED; actual outgoing hash/cap and returned count verified'})
 byunmet=[]
 for phase,field in [('source','source_detail'),('calculation','calculation_detail'),('write','write_detail'),('validation','validation_detail')]:
  for kv in ('B16','F4'):
   xs=[x for x in details if x['kv']==kv and x['first_unmet']==phase];byunmet.append({'first_unmet':phase,'kv':kv,'n':len(xs),'subtype_counts':dict(collections.Counter(x[field]for x in xs)),'episode_ids_by_subtype':{k:[x['episode_id']for x in xs if x[field]==k]for k in sorted({x[field]for x in xs})}})
 successes=[];first_divergences=[]
 for tid in sorted({e['task_id']for e in ev.episodes if e['VERIFIED_WORKFLOW_SUCCESS']}):
  for cap in (256,1024):
   good=lookup[(tid,'F4',32,cap)];g=independent_oracle(ev.tasks[tid]);earlyfalse=any(e['name']=='validate_state'and e['result'].get('valid')is False for e in good['events'])
   successes.append({'task_id':tid,'cap':cap,'episode_id':good['episode_id'],'same_task_repeated_at_other_cap':True,'parsed_errors':len([x for x in good['errors']if x['type']=='PARSE_ERROR']),'early_invalid_validation':earlyfalse,'recovery_classification':'EARLY_VALIDATION_FALSE_THEN_CURRENT_VALIDATION_TRUE'if earlyfalse else'NO_PRIOR_ERROR_ON_SUCCESS_PATH','correct_source':g['source_id'],'events':[{'event_id':x['event_id'],'name':x['name'],'args':x['arguments'],'result':x['result'],'generated_after_event_ids':x['generated_after_event_ids']}for x in good['events']]})
   for kv,menu in [('B16',32),('F4',8)]:
    other=lookup[(tid,kv,menu,cap)];focal=None
    for i,(x,y)in enumerate(zip(other['responses'],good['responses'])):
     sameinput=x['input_token_sha256']==y['input_token_sha256'];sameobserv=x['canonical_observation_hash']==y['canonical_observation_hash']and x['state_digest']==y['state_digest']
     if x['output_token_ids']!=y['output_token_ids']:
      focal={'turn':i,'full_input_token_hash_equal':sameinput,'full_history_bytes_equal':ev.messages(x)==ev.messages(y),'business_observation_and_state_equal':sameobserv,'other_calls':[s['parsed']for s in x['parsed_slots']],'F4_m32_calls':[s['parsed']for s in y['parsed_slots']],'interpretation':'FIRST_DIFFERENCE_AT_SHARED_COMPLETE_INPUT'if sameinput else'DIFFERENT_TOOL_MENU_INPUTS_FROM_START; same state is not same policy input'};break
    first_divergences.append({'task_id':tid,'cap':cap,'comparison':f'{kv}/menu{menu} vsF4/menu32','other_episode_id':other['episode_id'],'success_episode_id':good['episode_id'],'other_unmet':other['unmet_obligations'],'first_divergence':focal,'no_alignment_after_divergence':True})
 falsefinal=[]
 for e in ev.episodes:
  if e['kv']=='F4'and e['FINAL_ANSWER_CORRECT']and not e['VERIFIED_WORKFLOW_SUCCESS']:
   d=next(x for x in details if x['episode_id']==e['episode_id']);falsefinal.append({'episode_id':e['episode_id'],'unmet_reported':e['unmet_obligations'],'validation_events':[x for x in e['events']if x['name']=='validate_state'],'dependency_violations':d['dependency_violations'],'observed_final':e['final'],'reason':'NO_VALIDATION_CALL_AFTER_WRITE'if not any(x['name']=='validate_state'for x in e['events'])else'ONLY_STALE_FALSE_VALIDATION; write generated before observing calculation result'})
 timeline=load(ROOT/'evidence/freeze_timeline.json');amendments=[]
 impact={1:'startup memory admission only; same explicit pool',2:'new-env nvcc/crt/cccl alignment; no task/weight change',3:'local structured history normalization and input identity checks; outgoing request body unchanged',4:'new-env NVVM alignment only',5:'private JIT linker paths only',6:'P0 cancellation probe correction; raw marker-order alignment/parser accounting and regression tests finalized beforeP1',7:'P0-only abort log observability; P1 logging unchanged',8:'explicit OFF strict-tool policy; CPU48-case structured_outputs gate showed None beforeP1'}
 for i in range(1,9):
  rel=f'specs/amendment{i:02d}.json';receipt=load(ROOT/'evidence'/rel);containing=[]
  for freeze in timeline:
   f=load(ROOT/'evidence'/freeze['freeze'])
   if any(row['path']==rel for row in f['files']):containing.append({'freeze':freeze['freeze'],'created_utc':freeze['created_utc'],'source_sha256':freeze['source_sha256']})
  amendments.append({'id':i,'change_and_impact':impact[i],'original_document':receipt,'first_hash_receipts':sorted(containing,key=lambda x:x['created_utc']or'')[:1],'p1_all96_single_source_hash':len({e['execution_source_sha256']for e in ev.episodes})==1,'p1_source_hash':ev.episodes[0]['execution_source_sha256'],'timestamps_from_freeze_receipts_not_mtime':True})
 cache=[]
 for kv,bpt in [('B16',147456),('F8',73728),('F4',41472)]:
  before=load(ROOT/f'evidence/results/p0_diagnostics_r3/{kv}_final_config_cache_before.json');after=load(ROOT/f'evidence/results/p0_diagnostics_r3/{kv}_final_config_cache_after.json');conf=after['cache_config'];size=conf['kv_cache_size_tokens']*bpt;assert size==after['actual_unique_storage_bytes'];assert len(after['layers'])==36
  scales=[(x['q_scale'],x['k_scale'],x['v_scale'])for x in after['layers']];scalesbefore=[(x['q_scale'],x['k_scale'],x['v_scale'])for x in before['layers']];assert scales==scalesbefore
  cache.append({'kv':kv,'layers':36,'bytes_per_token':bpt,'capacity':conf['kv_cache_size_tokens'],'blocks':conf['num_gpu_blocks'],'block_size':conf['block_size'],'capacity_times_bytes_per_token':size,'actual_pool_bytes':after['actual_unique_storage_bytes'],'unique_storages':after['unique_storage_count'],'scale_stable':True,'global_scales':sorted(set(scales)),'nvfp4_fa2_all':all(x['nvfp4_fa2']for x in after['layers'])if kv=='F4'else None,'use_xqa':sorted({str(x['use_xqa'])for x in after['layers']}),'xqa_selection_reason':'NOT_RECORDED; no reason inferred','full_model_logit_finite_independent':'NOT_RUN_ORIGINAL; not upgraded by this audit'})
 orig=load(ROOT/'evidence/results/p1_r1/summary.json');a16=load(ROOT/'evidence/results/p1_r1/B16_attempt00.json');a4=load(ROOT/'evidence/results/p1_r1/F4_attempt00.json');worker=orig['worker_wall_seconds'];parts=a16['attempt_wall_seconds']+a4['attempt_wall_seconds'];timing={'p1_worker_seconds':worker,'attempt_sum_seconds':parts,'difference_seconds':worker-parts,'before_first_attempt_seconds':a16['elapsed_worker_seconds']-a16['attempt_wall_seconds'],'between_attempt_timer_samples_seconds':a4['elapsed_worker_seconds']-a16['elapsed_worker_seconds']-a4['attempt_wall_seconds'],'after_last_attempt_seconds':worker-a4['elapsed_worker_seconds'],'definition':'worker begins before freeze/tokenizer/preparation; attempt begins before server start and includes stop; worker ends after summary/I/O. Distinct sampling clocks, not a speedup.'}
 save(a.output/'slot_syntax.json',slot_syntax);save(a.output/'event_boundaries.json',event_counts);save(a.output/'cap_statistics.json',capstats);save(a.output/'obligation_subtypes.json',byunmet);save(a.output/'f4_success_paths.json',successes);save(a.output/'first_divergences.json',first_divergences);save(a.output/'final_correct_not_verified.json',falsefinal);save(a.output/'amendment_audit.json',amendments);save(a.output/'cache_time_audit.json',{'cache':cache,'timing':timing,'small_decoder_static_review':{'source':'evidence/source_static/kernel_check.py','two_outputs':'deq=torch.empty_like(kv) is written by FlashInfer dequantizer; independent=torch.stack of LUT unpack-and-scale calculations; distinct allocations, not one tensor/view compared with itself','same_input_cache':'both intentionally decode the same packed cache; quantization difference against original BF16 separated','shape':'queryheads32/KVheads8/head_dim128, sequence96,6pages16, NHD/HND,2-layer neighbor integrity','GPU_test_rerun':False}})
 print(json.dumps({'status':'PASS','event_rows':len(event_counts),'cap_groups':len(capstats),'source_rows':len(byunmet),'successful_conditions':len(successes),'first_divergences':len(first_divergences),'amendments':8,'time_difference_seconds':worker-parts}))
if __name__=='__main__':main()
