"""Actual adjacent frozen-source diffs; no mtime-based chronology."""
import difflib,json,pathlib
from audit_baseline import ROOT,load,save

def main():
 timeline=sorted(load(ROOT/'evidence/freeze_timeline.json'),key=lambda x:x['created_utc']or'');rows=[]
 for before,after in zip(timeline,timeline[1:]):
  bf=load(ROOT/'evidence'/before['freeze']);af=load(ROOT/'evidence'/after['freeze']);bm={x['path']:x for x in bf['files']};am={x['path']:x for x in af['files']};changes=[]
  for path in sorted(set(bm)|set(am)):
   x,y=bm.get(path),am.get(path)
   if x and y and x['sha256']==y['sha256']:continue
   entry={'path':path,'before_sha256':x['sha256']if x else None,'after_sha256':y['sha256']if y else None,'kind':'ADDED'if not x else'REMOVED'if not y else'MODIFIED'}
   if path.startswith('src/'):
    old=(ROOT/'evidence/historical_sources'/(x['sha256']+'.py')).read_text()if x else'';new=(ROOT/'evidence/historical_sources'/(y['sha256']+'.py')).read_text()if y else''
    name=f'{len(rows):02d}__'+path.replace('/','_')+'.diff';p=ROOT/'evidence/adjacent_source_diffs'/name;p.parent.mkdir(exist_ok=True);p.write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=before['freeze']+':'+path,tofile=after['freeze']+':'+path)));entry['diff_path']=str(p.relative_to(ROOT))
   changes.append(entry)
  rows.append({'before_freeze':before['freeze'],'before_created_utc':before['created_utc'],'after_freeze':after['freeze'],'after_created_utc':after['created_utc'],'changes':changes})
 launch={kv:load(ROOT/f'evidence/provenance/logs/runs/p1_{kv}_00/launch_private.json')for kv in ('B16','F4')}
 commands={kv:list(x['command'])for kv,x in launch.items()}
 for kv,cmd in commands.items():cmd[cmd.index('--kv-cache-dtype')+1]='KV_DTYPE_VARIABLE'
 assert commands['B16']==commands['F4']
 actuals={kv:load(ROOT/f'evidence/results/p1_r1/{kv}_cache_before.json')for kv in ('B16','F4')};assert all(len(x['layers'])==36 for x in actuals.values())
 save(ROOT/'results/adjacent_source_deltas.json',{'status':'PASS','chronology':'freeze.created_utc only; source hash rows verified separately; not filesystem mtime','transitions':rows})
 save(ROOT/'results/launch_comparison.json',{'status':'PASS','same_launch_arguments_except_kv_dtype':True,'common_command':commands['B16'],'actual_model_parameter_signature':{kv:actuals[kv].get('parameter_signature','NOT_RECORDED')for kv in actuals},'request_options':'All478 reconstructed payload hashes checked in replay; temperature0, tools auto, thinkingFalse, ignore_eosFalse, caps256/1024 only. No live endpoint query.','actual_logged_cache_tf32':{kv:actuals[kv]['tf32']for kv in actuals},'common_flags_verified_from_frozen_source':'source_static/server_manager.py env and argv; no new launch','kernel_difference':'cache writer/reader dtype-specific path is intended; common FlashInfer family does not mean identical kernels','model_identity':'existing recorded revision/config/shard hashes only; no new whole-weight hashing'})
 print(json.dumps({'status':'PASS','adjacent_freeze_transitions':len(rows),'launch_differences_only_kv':True}))
if __name__=='__main__':main()
