import argparse,datetime,hashlib,json,pathlib,subprocess,time,urllib.parse
from audit_baseline import ROOT,load,save,digest

def main():
 p=argparse.ArgumentParser();p.add_argument('--case',type=pathlib.Path,required=True);a=p.parse_args();c=a.case.resolve();before=load(ROOT/'provenance/preservation_start.json');mismatch=[]
 for row in before:
  f=c/row['path']
  if not f.is_file()or f.is_symlink():mismatch.append({'path':row['path'],'status':'MISSING_OR_SYMLINK'});continue
  b=f.read_bytes()
  if len(b)!=row['bytes']or hashlib.sha256(b).hexdigest()!=row['sha256']:mismatch.append({'path':row['path'],'status':'BYTES_OR_HASH_CHANGED'})
 after={str(f.relative_to(c))for f in c.rglob('*')if f.is_file()and not f.is_symlink()and'__pycache__'not in f.parts};added=sorted(after-{r['path']for r in before});assert not mismatch and not added
 repo=c.parent.parent
 def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
 start=load(ROOT/'provenance/start.json');head=git('rev-parse','HEAD');status=git('status','--short');index=git('diff','--cached','--name-only');assert head==start['git_head']and status==start['git_status']and not index
 remote=git('remote','get-url','origin');u=urllib.parse.urlsplit(remote);remote_clean=urllib.parse.urlunsplit((u.scheme,u.hostname or'',u.path,'',''))if u.scheme else'CONFIGURED_LOCAL_OR_SSH_REMOTE'
 agents=[str((q/'AGENTS.md').relative_to(q))for q in [repo,*repo.parents]if(q/'AGENTS.md').exists()]
 elapsed=time.monotonic()-start['start_monotonic'];receipt={'status':'PASS','registered_analysis_started_utc':start['started_utc'],'completed_local_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'registered_analysis_wall_seconds':elapsed,'initial_readonly_preflight':'not separately timed; before registered output start','budget_seconds':5400,'within_registered_budget':elapsed<=5400,'original_case_files_checked':len(before),'mismatches':mismatch,'added_original_case_files':added,'git_head':head,'branch':git('branch','--show-current'),'git_status_unchanged':status,'staged_paths':[],'origin':remote_clean,'ancestor_agents_files_found':agents,'source_package_sha256':load(ROOT/'results/p1_source_identity.json')['source_sha256'],'fresh_gpu_generation_requests':0,'model_loads':0,'server_starts_or_live_endpoint_calls':0,'processes_terminated':0,'package_installs_or_upgrades':0,'remote_changes':0,'environment_scope':'CPU subprocess variables only; no parent/service setting edits; no new full-weight hashing','tokenizer_files_rehashed':2,'original_science_or_guidance_files_modified':0}
 save(ROOT/'preservation.json',receipt)
 code=[]
 for f in sorted(list((ROOT/'src').glob('*.py'))+list((ROOT/'tests').glob('*.py'))):code.append({'path':str(f.relative_to(ROOT)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
 save(ROOT/'provenance/audit_code_freeze.json',{'files':code,'audit_code_sha256':digest(code),'source_is_posthoc_cpu_audit':True,'execution_source_of_original_P1':'ab8463e9bfde41564e44a863bc1159dfecf26cada54a7fdceea5ebec127e53ee','not_a_git_commit':True})
 save(ROOT/'audit_receipt.json',{'status':'LOCAL_CPU_AUDIT_COMPLETE_PENDING_ARCHIVE_VERIFICATION','evidence_kind':'STORED_TRACE_REPLAY + separately labeled SYNTHETIC_CONTRACT_TEST','episodes':96,'requests':478,'raw_call_slots':614,'tool_events':535,'original_score_discrepancies':0,'source_frozen_files_verified':35,'cpu_tests':{'historical_core_run':33,'historical_core_not_run_scope':1,'historical_postreview_run':3,'new_unique_run':15,'repeats_not_counted_as_new':True},'input_retokenization':{'requests':478,'initial_unique_inputs':24,'mismatches':0,'raw_output_decodes':478,'model_loaded':False,'torch_or_transformers_imported':False},'new_gpu_requests':0,'registered_analysis_wall_seconds_at_local_finish':elapsed,'scope_limits':['server-internal normalized sampling cap not recorded','exact future final after rejected tool unknown','no new GPU/serving/kernel tests','model/tokenizer payloads excluded from bundle','full-model logit finite check remains original NOT_RUN'],'preservation_receipt':'preservation.json','original_P1_source_sha256':receipt['source_package_sha256'],'audit_code_sha256':digest(code)})
 print(json.dumps({'status':'PASS','files':len(before),'mismatches':0,'registered_minutes':elapsed/60,'source_sha256':digest(code)}))
if __name__=='__main__':main()
