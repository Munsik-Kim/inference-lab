"""Public stdlib CPU verifier, reconstructed evidence and fresh outputs only."""
import argparse,hashlib,json,os,pathlib,re,subprocess,sys,time
from audit_baseline import ROOT,Evidence,run,load,save

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args();out=a.output.resolve()
 if out.exists():raise ValueError('fresh output directory required')
 if out==ROOT or ROOT in out.parents:raise ValueError('verification output must be outside the review bundle')
 out.mkdir(parents=True);start=time.monotonic();manifest=load(ROOT/'MANIFEST.json');count=0
 for row in manifest['files']:
  path=pathlib.PurePosixPath(row['path']);assert not path.is_absolute()and'..'not in path.parts
  f=ROOT/path;assert f.is_file()and not f.is_symlink();b=f.read_bytes();assert len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256'];count+=1
 actual={str(f.relative_to(ROOT))for f in ROOT.rglob('*')if f.is_file()}
 assert actual=={r['path']for r in manifest['files']}|{'MANIFEST.json'},'unexpected or missing bundle files'
 ev=Evidence();summary=run(out/'replay',ev)
 expected=ROOT/'results/replay_r2';compare=[]
 for name in ['episode_ledger.csv','request_ledger.csv','call_ledger.jsonl','cap_pairs.csv','state_correct_without_final.csv','cell_comparison.csv','tool_limit_cases.json','obligation_diagnostics.json','oracle_audit.json','summary.json']:
  assert (out/'replay'/name).read_bytes()==(expected/name).read_bytes(),name;compare.append(name)
 env=os.environ.copy();env.update({'CUDA_VISIBLE_DEVICES':'','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(ROOT/'src')+os.pathsep+str(ROOT/'evidence/source')})
 commands=[('tests',[sys.executable,'-B',str(ROOT/'src/run_tests.py'),'--output',str(out/'tests')]),('supplement',[sys.executable,'-B',str(ROOT/'src/supplement.py'),'--replay',str(out/'replay'),'--output',str(out/'supplement')]),('final_extraction',[sys.executable,'-B',str(ROOT/'src/final_extraction_audit.py'),'--output',str(out/'final_extraction.json')])]
 receipts=[]
 for label,cmd in commands:
  t=time.monotonic()
  with(out/(label+'.log')).open('w')as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
  receipts.append({'label':label,'exit_code':r.returncode,'wall_seconds':time.monotonic()-t});assert r.returncode==0,label
 for f in(ROOT/'results/supplement_r1').glob('*.json'):assert f.read_bytes()==(out/'supplement'/f.name).read_bytes(),f.name
 assert load(out/'final_extraction.json')==load(ROOT/'results/final_extraction_audit_r2.json')
 tokenrec=load(ROOT/'results/tokenizer_audit.json');lookup={(e['episode_id'],r['turn']):r for e in ev.episodes for r in e['responses']}
 assert len(tokenrec['rows'])==478
 for row in tokenrec['rows']:assert row['input_token_sha256']==lookup[(row['episode_id'],row['turn'])]['input_token_sha256']
 report=(ROOT/'REPORT.ko.md').read_text();findings=load(ROOT/'findings.json');assert len(findings)==13
 for g in summary['groups']:
  expectedrow='| '+' | '.join(str(x)for x in [g['kv'],g['menu'],g['cap']]+[f"{g['reported_'+k]}/{g['recomputed_'+k]}"for k in ('verified','state','final','false_done')])+' |';assert expectedrow in report
 links=0
 for path in [ROOT/'REPORT.ko.md',ROOT/'REPRODUCE.ko.md']:
  for target in re.findall(r'\]\(([^)]+)\)',path.read_text()):
   if target.startswith(('http:','https:','#')):continue
   target=target.split('#')[0];assert (path.parent/target).exists(),(path.name,target);links+=1
 assert not any(x in sys.modules for x in ('torch','transformers','vllm'))
 save(out/'verification.json',{'status':'PASS','manifest_files':count,'episodes_replayed':96,'requests_sse_reassembled':478,'call_slots':614,'tool_events_replayed':535,'all_ledger_files_byte_identical':compare,'commands':receipts,'tests':load(out/'tests/tests.json'),'report_cell_rows_match':8,'relative_links_checked':links,'new_gpu_requests':0,'network':'subprocess socket/import guard active','tokenizer_reexecution':'NOT_INCLUDED in stdlib bundle verification; local recorded478 exact-ID replay independently checked against included input hashes','original_code_changed':False,'wall_seconds':time.monotonic()-start})
 print(json.dumps({'status':'PASS','files':count,'episodes':96,'requests':478,'new_gpu_requests':0}))
if __name__=='__main__':main()
