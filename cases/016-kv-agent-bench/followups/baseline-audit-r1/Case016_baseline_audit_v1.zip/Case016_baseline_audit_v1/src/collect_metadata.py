import argparse,hashlib,json,pathlib
from audit_baseline import ROOT,load,save,digest

def main():
 p=argparse.ArgumentParser();p.add_argument('--case',type=pathlib.Path,required=True);a=p.parse_args();c=a.case;rows=[]
 paths=['results/p0_gates.json','results/p0_overview.json','results/p0_diagnostics_r2/F4_kernel_profile.json','results/p0_diagnostics_r2/registration.json','results/cpu_r1/structured_mask_gate.json','provenance/execution_source_map.json','provenance/log_sanitization.json']
 for kv in ('B16','F8','F4'):paths +=[f'results/p0_diagnostics_r3/{kv}_final_config_cache_{x}.json'for x in ('before','after')]
 for kv in ('B16','F4'):paths +=[f'results/p1_r1/{kv}_cache_{x}.json'for x in ('before','after')]+[f'provenance/logs/runs/p1_{kv}_00/{n}'for n in ('launch_private.json','server.log','shutdown.json')]
 for f in (c/'results').rglob('*kernel*.json'):
  if f.stat().st_size<100000:paths.append(str(f.relative_to(c)))
 for path in dict.fromkeys(paths):
  f=c/path;b=f.read_bytes();out=ROOT/'evidence'/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b);rows.append({'original_path':path,'retained_path':str(out.relative_to(ROOT)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'transformation':'BYTE_IDENTICAL to existing public candidate; earlier log sanitization mapping retained'})
 freeze=load(c/'results/p1_r1/code_freeze.json');checks=[]
 assert digest(freeze['files'])==freeze['source_sha256']=='ab8463e9bfde41564e44a863bc1159dfecf26cada54a7fdceea5ebec127e53ee'
 for f in freeze['files']:
  b=(c/f['path']).read_bytes();checks.append({'path':f['path'],'bytes_match':len(b)==f['bytes'],'hash_match':hashlib.sha256(b).hexdigest()==f['sha256']})
 assert all(x['hash_match']and x['bytes_match']for x in checks)
 save(ROOT/'provenance/additional_sources.json',rows);save(ROOT/'results/p1_source_identity.json',{'status':'PASS','source_sha256':freeze['source_sha256'],'git_base':freeze['git_commit'],'files':checks,'data_tasks_and_token_manifest':'whole-file hash only; EVAL records not decoded or analyzed','source_objects_distinct':True})
 print(json.dumps({'status':'PASS','extra_small_files':len(rows),'p1_frozen_files_verified':len(checks)}))
if __name__=='__main__':main()
