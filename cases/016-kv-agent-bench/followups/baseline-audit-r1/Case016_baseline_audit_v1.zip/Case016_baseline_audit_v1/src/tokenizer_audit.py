"""Optional CPU-only exact tokenizer/template replay; no Transformers/Torch/model."""
import argparse,copy,hashlib,json,pathlib,sys
from audit_baseline import ROOT,Evidence,digest,save,token_hash

def main():
 p=argparse.ArgumentParser();p.add_argument('--snapshot',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args()
 import tokenizers,jinja2
 from jinja2.sandbox import ImmutableSandboxedEnvironment
 cfg=json.loads((a.snapshot/'tokenizer_config.json').read_text());template=cfg['chat_template'];env=ImmutableSandboxedEnvironment(trim_blocks=True,lstrip_blocks=True,extensions=['jinja2.ext.loopcontrols']);env.filters['tojson']=lambda x,**kw:json.dumps(x,ensure_ascii=False,**kw)
 def fail(message):raise ValueError(message)
 env.globals['raise_exception']=fail;compiled=env.from_string(template);tok=tokenizers.Tokenizer.from_file(str(a.snapshot/'tokenizer.json'));ev=Evidence();rows=[];positions=[];rawrows=[];initial_seen=set()
 from kv_agent_bench.fixture_generator import tools,message_parts
 for e in ev.episodes:
  for r in e['responses']:
   messages=ev.messages(r)
   for m in messages:
    for c in m.get('tool_calls',[]):
     args=c['function'].get('arguments')
     if type(args)is str:c['function']['arguments']=json.loads(args)
   rendered=compiled.render(messages=messages,tools=tools(e['menu']),add_generation_prompt=True,enable_thinking=False,bos_token=cfg.get('bos_token'),eos_token=cfg.get('eos_token'))
   ids=tok.encode(rendered,add_special_tokens=False).ids;stored=ev.ids(r['prompt_ids_ref']);assert ids==stored,(e['episode_id'],r['turn'],len(ids),len(stored));decoded=tok.decode(r['output_token_ids'],skip_special_tokens=False);assert decoded==r['raw_text']
   rows.append({'episode_id':e['episode_id'],'turn':r['turn'],'tokens':len(ids),'input_token_sha256':token_hash(ids),'raw_text_sha256':hashlib.sha256(decoded.encode()).hexdigest(),'exact_ids_equal':True,'raw_output_decode_equal':True})
   if r['turn']==0:
    key=(e['task_id'],e['menu'])
    if key not in initial_seen:
     initial_seen.add(key);parts=message_parts(ev.tasks[e['task_id']]);offsets=[len(tok.encode(rendered[:rendered.index(part)],add_special_tokens=False).ids)for part in parts[:3]]
     assert offsets==[3600,5500,7350]and len(ids)==8192
     positions.append({'task_id':e['task_id'],'menu':e['menu'],'tokens':len(ids),'offsets':offsets,'required_text_exactly_present':all(part in rendered for part in parts),'no_initial_fact_truncation':True})
 assert 'torch'not in sys.modules and 'transformers'not in sys.modules
 files=[{'label':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for f in [a.snapshot/'tokenizer.json',a.snapshot/'tokenizer_config.json']]
 save(a.output,{'status':'PASS','model_loaded':False,'gpu_requests':0,'tokenizers':tokenizers.__version__,'jinja2':jinja2.__version__,'requests_retokenized':len(rows),'initial_unique_inputs':len(initial_seen),'input_ids_exact_matches':len(rows),'raw_output_exact_decodes':len(rows),'files':files,'positions':positions,'rows':rows,'implementation':'Direct tokenizers CPU + frozen tokenizer_config Jinja template; every rendered result checked against actual server IDs. No transformers or torch imported.'});print(json.dumps({'status':'PASS','requests':len(rows),'initial_inputs':len(positions),'torch_imported':False,'transformers_imported':False}))
if __name__=='__main__':main()
