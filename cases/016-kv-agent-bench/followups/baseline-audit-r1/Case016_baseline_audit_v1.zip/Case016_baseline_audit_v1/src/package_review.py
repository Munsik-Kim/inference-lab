"""Package a bounded audit subset, preserving all96 raw replay evidence."""
import argparse,ast,hashlib,json,pathlib,re,shutil,stat,time,zipfile
from audit_baseline import ROOT,load,save

def selected():
 roots=['src','tests','evidence','provenance','logs','results/replay_r2','results/supplement_r1','results/tests_r1']
 paths=[]
 for rel in roots:
  for f in(ROOT/rel).rglob('*'):
   if f.is_file()and not f.is_symlink()and'__pycache__'not in f.parts and'fixtures'not in f.relative_to(ROOT).parts:paths.append(f)
 for rel in ['READ_FIRST.ko.txt','REPORT.ko.md','REPRODUCE.ko.md','findings.json','bundle_coverage.json','preservation.json','audit_receipt.json','LICENSE.txt','results/budget_boundary_tests.json','results/tokenizer_audit.json','results/p1_source_identity.json','results/final_extraction_audit_r2.json','results/adjacent_source_deltas.json','results/launch_comparison.json']:paths.append(ROOT/rel)
 return sorted(set(paths))

def build(stage):
 if stage.exists():raise ValueError('fresh bundle stage required')
 stage.mkdir(parents=True);rows=[];privacy=[]
 for f in selected():
  b=f.read_bytes();rel=f.relative_to(ROOT);target=stage/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
  if f.suffix in('.json','.jsonl','.py','.md','.txt','.csv','.log','.diff'):
   text=b.decode()
   for pat in [r'/home/[A-Za-z][A-Za-z0-9_.-]*/',r'/mnt/[cd]/Users/',r'hf_[A-Za-z0-9]{25,}',r'gh[pousr]_[A-Za-z0-9]{20,}']:
    if re.search(pat,text):privacy.append({'file':str(rel),'pattern':pat})
  if f.suffix=='.py':ast.parse(b.decode(),filename=str(rel))
  if f.suffix=='.json':json.loads(b,parse_constant=lambda x:(_ for _ in()).throw(ValueError(x)))
  rows.append({'path':str(rel),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 assert not privacy,privacy
 save(stage/'MANIFEST.json',{'schema':'case016-baseline-audit-bundle-v1','files':rows,'self_excluded':True,'scope':'All96 stored endpoint replay and478 raw SSE reconstruction; no GPU/weights/venv/EVAL payload','source_manifest':'provenance/source_manifest.json'})
 return rows

def archive(stage,path,extracted):
 if path.exists()or extracted.exists():raise ValueError('fresh archive and extraction required')
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for f in sorted(stage.rglob('*')):
   if f.is_file():z.write(f,'Case016_baseline_audit_v1/'+str(f.relative_to(stage)))
 assert path.stat().st_size<=10*1024*1024,'archive exceeds10MiB'
 names=set();count=0
 with zipfile.ZipFile(path)as z:
  assert z.testzip()is None
  for info in z.infolist():
   p=pathlib.PurePosixPath(info.filename);assert not p.is_absolute()and'..'not in p.parts and'\\'not in info.filename
   assert info.filename not in names;names.add(info.filename);assert not stat.S_ISLNK(info.external_attr>>16);count+=1
  z.extractall(extracted)
 manifest=load(stage/'MANIFEST.json');case=extracted/'Case016_baseline_audit_v1'
 for row in manifest['files']:
  b=(case/row['path']).read_bytes();assert len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256']
 receipt={'status':'PASS','zip_name':path.name,'zip_bytes':path.stat().st_size,'zip_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'entries':count,'selected_content_bytes':sum(r['bytes']for r in manifest['files']),'content_hashes':len(manifest['files']),'manifest_self_sha256':hashlib.sha256((stage/'MANIFEST.json').read_bytes()).hexdigest(),'crc_safe_paths_duplicate_symlink':'PASS','within_target5MiB':path.stat().st_size<=5*1024*1024,'new_gpu_requests':0,'no_model_or_env_or_EVAL_payload':True}
 return receipt

def main():
 p=argparse.ArgumentParser();p.add_argument('--stage',type=pathlib.Path,required=True);p.add_argument('--zip',type=pathlib.Path);p.add_argument('--extract',type=pathlib.Path);p.add_argument('--receipt',type=pathlib.Path,required=True);a=p.parse_args()
 rows=build(a.stage)
 if a.zip:
  if a.extract is None:raise ValueError('--extract required')
  r=archive(a.stage,a.zip,a.extract)
 else:r={'status':'STAGED','files':len(rows)}
 save(a.receipt,r);print(json.dumps(r))
if __name__=='__main__':main()
