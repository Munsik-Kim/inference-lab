import argparse,json,pathlib,sys,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT/'evidence/source'),str(ROOT/'src')]
p=argparse.ArgumentParser();p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
loader=unittest.TestLoader();suite=loader.discover(str(ROOT/'evidence/tests'),pattern='test*.py')
def flatten(s):
 for x in s:
  if isinstance(x,unittest.TestSuite):yield from flatten(x)
  else:yield x
alltests=list(flatten(suite));assert len(alltests)==34
excluded=[t for t in alltests if t.id().endswith('test_split_ids_and_hashes_disjoint')]
assert len(excluded)==1
sets=[('historical_core',[t for t in alltests if t not in excluded]),('historical_postreview',list(flatten(loader.discover(str(ROOT/'evidence/publication/tests'),pattern='test*.py',top_level_dir=str(ROOT/'evidence/publication/tests'))))),('new_audit',list(flatten(loader.discover(str(ROOT/'tests'),pattern='test*.py',top_level_dir=str(ROOT/'tests')))))]
receipts=[]
for label,tests in sets:
 with(a.output/(label+'.log')).open('w')as f:result=unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.TestSuite(tests))
 receipts.append({'suite':label,'unique_tests_run':result.testsRun,'status':'PASS'if result.wasSuccessful()else'FAIL','test_names':[t.id()for t in tests],'failures':[t.id()for t,_ in result.failures],'errors':[t.id()for t,_ in result.errors]})
receipts.append({'suite':'historical_core_scope_exclusion','status':'NOT_RUN_SCOPE','test_names':[t.id()for t in excluded],'reason':'This test generates EVAL48. Current authorization explicitly excludes opening/analyzing/selecting EVAL; remaining33 historical tests run unchanged.'})
(a.output/'tests.json').write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(receipts));sys.exit(any(x['status']=='FAIL'for x in receipts))
