"""Lossless raw SSE storage: replace only repeated prompt ID arrays with references."""
import argparse,hashlib,json,pathlib,re,sys
from extract_evidence import ROOT,digest,save

def main():
 p=argparse.ArgumentParser();p.add_argument('--case',type=pathlib.Path,required=True);a=p.parse_args()
 tokens=json.loads((ROOT/'evidence/token_sequences.json').read_text());streams={};rows=json.loads((ROOT/'evidence/episodes.compact.json').read_text())
 def expand(key):
  r=tokens[key];return (expand(r['parent'])[:r['prefix']]if r['parent']else[])+r['suffix']
 for e in rows:
  original=json.loads((a.case/e['source_pointer']['path']).read_text())
  for r,q in zip(original['responses'],e['responses']):
   assert digest(r)==q['source_pointer']['excerpt_sha256'];lines=[]
   for line in r['raw_sse_lines']:
    m=re.search(r'"prompt_token_ids"\s*:\s*(\[[^\]]*\])',line)
    if not m:lines.append(line);continue
    ref=q['prompt_ids_ref'];ids=expand(ref);lex=m.group(1)
    if lex==json.dumps(ids,separators=(',',':')):style='compact'
    elif lex==json.dumps(ids):style='spaced'
    else:lines.append(line);continue
    lines.append({'before':line[:m.start(1)],'after':line[m.end(1):],'prompt_ids_ref':ref,'style':style})
   streams[q['raw_sse_sha256']]=lines
 save(ROOT/'evidence/raw_sse_pool.json',streams)
 print(json.dumps({'lossless_streams':len(streams),'requests':sum(len(e['responses'])for e in rows)}))
if __name__=='__main__':main()
