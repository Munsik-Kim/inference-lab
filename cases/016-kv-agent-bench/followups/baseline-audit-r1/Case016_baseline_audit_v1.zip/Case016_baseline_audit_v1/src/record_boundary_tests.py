import json,pathlib,sys,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT/'tests'),str(ROOT/'src'),str(ROOT/'evidence/source')]
import test_audit_boundaries as b
rows=[];original=b.AuditBoundaries.execute
original_runner=b.runner.run_episode
async def counted_runner(*args,**kwargs):
 invocation_count=0;original_request=kwargs['request']
 async def counted_request(*a,**k):
  nonlocal invocation_count
  invocation_count+=1
  return await original_request(*a,**k)
 kwargs['request']=counted_request
 e=await original_runner(*args,**kwargs);e['_audit_request_invocations']=invocation_count;return e
b.runner.run_episode=counted_runner

def record(self,*args,**kwargs):
 e=original(self,*args,**kwargs)
 rows.append({'test_id':self.id(),'evidence_kind':'SYNTHETIC_CONTRACT_TEST','terminal':e['terminal_reason'],'model_requests':e['model_calls'],'observed_mock_request_invocations':e['_audit_request_invocations'],'tool_attempts':e['tool_attempts'],'events':[{'name':x['name'],'status':x['status'],'result':x['result'],'generated_after_event_ids':x['generated_after_event_ids']}for x in e['events']],'verified':e['VERIFIED_WORKFLOW_SUCCESS'],'state_correct':e['STATE_CORRECT'],'final_correct':e['FINAL_ANSWER_CORRECT'],'unmet':e['unmet_obligations'],'raw_generated_names':[[s['parsed']['name']if s['parsed']else'PARSE_ERROR'for s in r['parsed_slots']]for r in e['responses']]});return e
b.AuditBoundaries.execute=record
suite=unittest.defaultTestLoader.loadTestsFromTestCase(b.AuditBoundaries)
with(ROOT/'logs/budget_boundary_tests.log').open('w')as f:result=unittest.TextTestRunner(stream=f,verbosity=2).run(suite)
timeout_row=next(x for x in rows if x['test_id'].endswith('test_request_timeout_distinct'))
assert timeout_row['observed_mock_request_invocations']==1 and timeout_row['model_requests']==0
(ROOT/'results/budget_boundary_tests.json').write_text(json.dumps({'status':'PASS'if result.wasSuccessful()else'FAIL','unique_new_test_names':result.testsRun,'repeat_of_tests_r1':True,'not_additional_unique_tests':True,'new_gpu_requests':0,'rows':rows},indent=2)+'\n');print(json.dumps({'status':'PASS'if result.wasSuccessful()else'FAIL','unique_tests':result.testsRun,'scripted_executions':len(rows)}));sys.exit(not result.wasSuccessful())
