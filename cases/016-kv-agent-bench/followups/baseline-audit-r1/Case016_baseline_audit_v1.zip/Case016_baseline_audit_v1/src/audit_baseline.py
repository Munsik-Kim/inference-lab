"""Independent CPU baseline audit. All96 stored traces; no model/network imports."""
import argparse,collections,copy,csv,hashlib,itertools,json,pathlib,re,statistics,struct,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'evidence/source'))
from kv_agent_bench.common import digest
from kv_agent_bench.tools import Fixture
from kv_agent_bench.scorer import assess
from kv_agent_bench.observations import ordered_slots
from kv_agent_bench.fixture_generator import tools,oracle,message_parts

def load(p):return json.loads(p.read_text())
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
def token_hash(ids):return sha(b''.join(struct.pack('<I',i)for i in ids))
def write_csv(p,rows):
 if not rows:return
 keys=list(dict.fromkeys(k for r in rows for k in r));p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('w',newline='')as f:
  w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
  for r in rows:w.writerow({k:json.dumps(v,ensure_ascii=False,separators=(',',':'))if isinstance(v,(dict,list))else v for k,v in r.items()})

def independent_oracle(t):
 v=t['visible'];eligible=[]
 for s in v['sources']:
  if s['arrival_time']<=v['cutoff']:eligible.append(s)
 if t['family']=='A':chosen=sorted(eligible,key=lambda s:(s['unit_price_minor'],s['source_id']))[0]
 elif t['family']=='B':chosen=sorted(eligible,key=lambda s:s['version'])[-1]
 elif t['family']=='C':chosen=sorted(eligible,key=lambda s:(s['event_time'],s['version']))[-1]
 else:chosen=sorted(eligible,key=lambda s:(s['version'],s['kind']=='cancel'))[-1]
 quantity=0 if chosen['kind']=='cancel'else v['quantity'];gross=quantity*chosen['unit_price_minor']*(100-v['discount_percent']);whole,rem=divmod(gross,100);total=whole+(rem>=50)
 return {'record_id':v['record_id'],'source_id':chosen['source_id'],'quantity':quantity,'unit_price_minor':chosen['unit_price_minor'],'discount_percent':v['discount_percent'],'total_minor':total,'source_version':chosen['version'],'status':'cancelled'if chosen['kind']=='cancel'else'active'}

def independent_verdict(t,events,rs,final,state,version,terminal):
 g=independent_oracle(t);same=lambda a,b:type(a)is type(b)and a==b
 expected={k:g[k]for k in ('record_id','total_minor','source_version','status')};expected['validated']=True
 fok=type(final)is dict and set(final)==set(expected)and all(same(final[k],v)for k,v in expected.items())
 sok=all(same(state.get(g['record_id'],{}).get(k),g[k])for k in ('total_minor','source_version','status'))
 initial=t['initial_state'];integrity=True
 for s in [state]+[e[k]for e in events for k in ('state_before','state_after')]:
  integrity &= set(s)==set(initial)and all(s[k]==initial[k]for k in initial if k!=g['record_id'])and s[g['record_id']].get('protected_tag')==initial[g['record_id']]['protected_tag']
 groups={k:[]for k in ('source','calculation','write','validation')}
 for i,e in enumerate(events):
  if e['status']!='SUCCESS':continue
  a=e['arguments'];n=e['name']
  if n=='read_source'and same(a.get('source_id'),g['source_id']):groups['source'].append(e)
  if n=='calculate_amount'and all(same(a.get(k),g[k])for k in ('quantity','unit_price_minor','discount_percent'))and e['result']['total_minor']==g['total_minor']:groups['calculation'].append(e)
  if n=='update_state'and all(same(a.get(k),g[k])for k in ('record_id','total_minor','source_version','status')):groups['write'].append(e)
  if n=='validate_state'and a=={'record_id':g['record_id']}and e['result'].get('valid')is True:groups['validation'].append(e)
 chain=None;seen=set(rs[-1]['available_result_event_ids'])if rs else set();indices={e['event_id']:i for i,e in enumerate(events)}
 for r,c,w,v in itertools.product(*groups.values()):
  if not indices[r['event_id']]<indices[c['event_id']]<indices[w['event_id']]<indices[v['event_id']]:continue
  if r['event_id']not in c['generated_after_event_ids']or c['event_id']not in w['generated_after_event_ids']:continue
  if v['event_id']not in seen or v['after_digest']!=digest(state)or v['version_after']!=version:continue
  chain=[e['event_id']for e in (r,c,w,v)];break
 unmet=[k for k,v in groups.items()if not v]
 if not unmet and not chain:unmet=['observable_dependency_chain']
 if not fok:unmet.append('final')
 if not sok:unmet.append('correct_state')
 if not integrity:unmet.append('protected_state')
 return {'VERIFIED_WORKFLOW_SUCCESS':bool(chain and sok and fok and integrity and terminal=='FINAL'),'STATE_CORRECT':bool(sok and integrity),'FINAL_ANSWER_CORRECT':bool(fok),'CLAIMED_DONE_WITH_WRONG_STATE':bool(type(final)is dict and final.get('validated')is True and not(sok and integrity)),'first_unmet_obligation':unmet[0]if unmet else None,'unmet_obligations':unmet,'chain':chain,'groups':{k:[e['event_id']for e in v]for k,v in groups.items()}}

class Evidence:
 def __init__(self,root=ROOT):
  self.root=root;self.objects=load(root/'evidence/objects.json');self.tokens=load(root/'evidence/token_sequences.json');self.streams=load(root/'evidence/raw_sse_pool.json');self.token_cache={};self.episodes=load(root/'evidence/episodes.compact.json');self.tasks={t['task_id']:t for t in load(root/'evidence/dev_tasks.json')}
 def ids(self,key):
  if key not in self.token_cache:
   t=self.tokens[key];self.token_cache[key]=(self.ids(t['parent'])[:t['prefix']]if t['parent']else[])+t['suffix'];assert digest(self.token_cache[key])==key
  return self.token_cache[key]
 def messages(self,r):return copy.deepcopy(self.objects[r['messages_ref']])
 def stream(self,r):
  lines=[]
  for line in self.streams[r['raw_sse_sha256']]:
   if isinstance(line,str):lines.append(line)
   else:
    sep=(',',':')if line['style']=='compact'else None
    lines.append(line['before']+json.dumps(self.ids(line['prompt_ids_ref']),separators=sep)+line['after'])
  assert digest(lines)==r['raw_sse_sha256'];return lines

def assemble(lines):
 # Independent choice/index/id-aware assembler. n=1 must be confirmed, not assumed.
 choices={};usage=None;prompt=None;meta={'role_only_chunks':0,'done_markers':0,'duplicate_id_conflicts':[],'id_repeats':0,'name_fragments':0,'argument_fragments':0}
 for line in lines:
  if not line.startswith('data: '):continue
  if line[6:]=='[DONE]':meta['done_markers']+=1;continue
  obj=json.loads(line[6:])
  if obj.get('usage')is not None:usage=obj['usage']
  if obj.get('prompt_token_ids')is not None:prompt=obj['prompt_token_ids']
  for ch in obj.get('choices',[]):
   ci=ch.get('index',0);a=choices.setdefault(ci,{'content':'','calls':{},'ids':[],'finish':None,'stop':None});a['ids'].extend(ch.get('token_ids')or[]);d=ch.get('delta')or{}
   if d.get('role')and not(d.get('content')or d.get('tool_calls')or ch.get('token_ids')):meta['role_only_chunks']+=1
   a['content']+=d.get('content')or''
   if ch.get('finish_reason')is not None:a['finish']=ch['finish_reason']
   if ch.get('stop_reason')is not None:a['stop']=ch['stop_reason']
   for frag in d.get('tool_calls')or[]:
    idx=frag['index'];f=a['calls'].setdefault(idx,{'index':idx,'id':None,'type':'function','function':{'name':'','arguments':''}})
    if frag.get('id'):
     if f['id']not in (None,frag['id']):meta['duplicate_id_conflicts'].append([ci,idx,f['id'],frag['id']])
     if f['id']==frag['id']:meta['id_repeats']+=1
     f['id']=frag['id']
    fun=frag.get('function')or{}
    for k in ('name','arguments'):
     if fun.get(k):f['function'][k]+=fun[k];meta[k+'_fragments'if k=='name'else'argument_fragments']+=1
 assert set(choices)=={0},set(choices)
 a=choices[0];result={'content':a['content'],'tool_calls':[a['calls'][i]for i in sorted(a['calls'])],'output_token_ids':a['ids'],'prompt_token_ids':prompt,'usage':usage,'server_finish_reason':a['finish'],'server_stop_reason':a['stop']}
 assert not meta['duplicate_id_conflicts'];return result,meta

def diagnosis(t,e,events,rs,verdict):
 g=independent_oracle(t);reads=[v for v in events if v['name']=='read_source'];chosen={s['source_id']:s for s in t['visible']['sources']};wrong=[]
 for ev in reads:
  sid=ev['arguments'].get('source_id');s=chosen.get(sid)
  if s is None:kind='NONEXISTENT_ID'
  elif sid==g['source_id']:kind='CORRECT_SOURCE'
  elif s['arrival_time']>t['visible']['cutoff']:kind='AFTER_CUTOFF'
  elif t['family']=='A':kind='NOT_LOWEST_PRICE'
  elif t['family']=='B':kind='LOWER_VERSION'
  elif t['family']=='C':kind='OLDER_EVENT_TIME'
  elif t['family']=='D':kind='CANCEL_OR_VERSION_PRIORITY'
  else:kind='UNKNOWN'
  wrong.append({'event_id':ev['event_id'],'source_id':sid,'classification':kind,'delivered_in_later_request':any(ev['event_id']in r['available_result_event_ids']for r in rs)})
 source_detail='CORRECT_READ_EXECUTED'if verdict['groups']['source']else'NO_READ_ATTEMPT'if not reads else'+'.join(sorted({r['classification']for r in wrong}))
 calc=[v for v in events if v['name']=='calculate_amount'];write=[v for v in events if v['name']=='update_state'];val=[v for v in events if v['name']=='validate_state']
 deps=[]
 for v in calc:
  if not any(x in v['generated_after_event_ids']for x in verdict['groups']['source']):deps.append({'event_id':v['event_id'],'type':'CALC_WITHOUT_OBSERVED_CORRECT_READ'})
 for v in write:
  if not any(x in v['generated_after_event_ids']for x in verdict['groups']['calculation']):deps.append({'event_id':v['event_id'],'type':'WRITE_WITHOUT_OBSERVED_CORRECT_CALC'})
 return {'source_detail':source_detail,'reads':wrong,'calculation_detail':'NO_CALL'if not calc else'CORRECT_ARGS_AND_RESULT'if verdict['groups']['calculation']else'WRONG_ARGUMENT_VALUES','write_detail':'NO_CALL'if not write else'CORRECT_WRITE'if verdict['groups']['write']else'WRONG_ID_OR_VALUES','validation_detail':'NO_CALL'if not val else'NO_TRUE_VALIDATION'if not verdict['groups']['validation']else'TRUE_EXISTS_BUT_STALE_OR_UNOBSERVED'if not verdict['chain']else'OBSERVED_CURRENT_VALIDATION','dependency_violations':deps}

def run(output,ev):
 if output.exists():raise ValueError('fresh output required')
 output.mkdir(parents=True);episodes=[];requests=[];calls=[];details=[];six=[];state_rows=[];joint=collections.Counter();sse_meta=collections.Counter();ids_seen=set();original_mismatches=[];goldrows=[]
 for t in ev.tasks.values():
  g=independent_oracle(t);assert g==t['oracle']==oracle(t);goldrows.append({'task_id':t['task_id'],'gold':g,'status':'PASS','evidence_kind':'CPU_ORACLE_RECOMPUTATION'})
 for e in ev.episodes:
  assert e['episode_id']not in ids_seen;ids_seen.add(e['episode_id']);t=ev.tasks[e['task_id']];fx=Fixture(t,output/'fixtures'/e['episode_id'],e['menu']);seen=[];messages=ev.messages(e['responses'][0]);attempts=0;tokens=0;terminal='UNKNOWN';final=None;processed=0;allslots=0;rs=[];executed=[];per_calls=[];toollist=tools(e['menu']);last_admitted=None
  for r in e['responses']:
   assert terminal=='UNKNOWN';turn=r['turn'];initialstate=fx.snapshot();assert ev.messages(r)==messages
   assert r['available_result_event_ids']==seen and r['canonical_observation_hash']==digest([x for x in fx.events if x['event_id']in seen]);assert r['state_digest']==digest(initialstate)and r['state_version']==fx.version
   built,meta=assemble(ev.stream(r));sse_meta.update({k:v for k,v in meta.items()if isinstance(v,int)})
   for k,v in built.items():assert v== (ev.ids(r['prompt_ids_ref'])if k=='prompt_token_ids'else r.get(k)),(e['episode_id'],turn,k)
   assert ev.ids(r['input_ids_ref'])==ev.ids(r['prompt_ids_ref']);prompt=ev.ids(r['prompt_ids_ref']);assert token_hash(prompt)==r['input_token_sha256']==r['server_input_token_sha256'];assert len(prompt)==r['local_prompt_tokens']==r['actual_prompt_tokens']==r['usage']['prompt_tokens']
   assert sha((r['raw_text']or'').encode())==r['raw_utf8_sha256'];assert r['tools_hash']==digest(toollist)
   cap=min(e['cap'],8192-tokens,28672-len(prompt));assert cap==r['request_cap']and r['cap_bounds']=={'configured_cap':e['cap'],'remaining_episode_tokens':8192-tokens,'remaining_context_tokens':28672-len(prompt)}
   payload={'model':'case016-qwen3-4b','messages':messages,'tools':toollist,'tool_choice':'auto','temperature':0,'max_tokens':cap,'stream':True,'stream_options':{'include_usage':True},'return_token_ids':True,'chat_template_kwargs':{'enable_thinking':False},'ignore_eos':False}
   assert digest(payload)==r['request_hash'];assert len(built['output_token_ids'])==r['usage']['completion_tokens']<=cap
   slots=ordered_slots(r['raw_text'],built['tool_calls']);assert slots==r['parsed_slots'];allslots+=len(slots);tokens+=len(built['output_token_ids']);rs.append(r);accepted=[];new=[];frozen=tuple(seen)
   for i,s in enumerate(slots):
    admitted=attempts<6;before=fx.snapshot();row={'episode_id':e['episode_id'],'turn':turn,'call_index':i,'global_generated_slot':len(per_calls)+1,'raw_marker_present':'<tool_call>'in(r['raw_text']or''),'engine_call_present':s.get('server_call')is not None,'parser_accepted':s['parsed']is not None,'parsed':s['parsed'],'server_call':s.get('server_call'),'host_admitted':admitted,'attempt_ordinal':attempts+1 if admitted else None,'generated_after_event_ids':list(frozen),'pre_generation_history_hash':digest(ev.messages(r)),'pre_generation_state_digest':r['state_digest'],'state_before_execution_digest':digest(before),'rejection_reason':None,'event':None,'source_pointer':{**r['source_pointer'],'json_path':r['source_pointer']['json_path']+f'.parsed_slots[{i}]'}}
    if not admitted:
     terminal='TOOL_CALL_LIMIT';row['rejection_reason']='TOOL_CALL_LIMIT_NOT_EXECUTED'
    else:
     attempts+=1
     if s['parsed']is None:row['rejection_reason']='PARSE_ERROR_NO_CALLABLE'
     else:
      obj=s['parsed'];event=fx.execute(obj['name'],obj['arguments'],turn,i,frozen);row['event']=event;new.append(event);processed+=1
      accepted.append(s['server_call']or{'id':f'local_{turn}_{i}','type':'function','function':{'name':obj['name'],'arguments':json.dumps(obj['arguments'])}})
      row['rejection_reason']=event['error'];row['callable_executed']=event['status']=='SUCCESS';row['state_content_changed']=event['state_before']!=event['state_after'];row['state_version_changed']=event['version_after']!=event['version_before']
     if attempts==6:last_admitted={'request_turn':turn,'call_index':i,'slot':copy.deepcopy(row)}
    per_calls.append(row);calls.append(row)
   if slots:
    if accepted:
     messages.append({'role':'assistant','content':r['content']or None,'tool_calls':accepted})
     for call,event in zip(accepted,new):messages.append({'role':'tool','tool_call_id':call['id'],'content':json.dumps(event['result'],ensure_ascii=False)});seen.append(event['event_id'])
    if terminal!='TOOL_CALL_LIMIT'and not accepted:terminal='PARSE_STOP'
   else:
    try:answer=json.loads(built['content'].strip());final=answer if type(answer)is dict else None
    except (ValueError,TypeError):final=None
    terminal='FINAL'if final is not None else'TOKEN_LIMIT'if built['server_finish_reason']=='length'else'PARSE_STOP'
   requests.append({'episode_id':e['episode_id'],'kv':e['kv'],'menu':e['menu'],'configured_cap':e['cap'],'generation_turn':turn,'request_id':next((json.loads(line[6:]).get('id')for line in ev.stream(r)if line.startswith('data: ')and line[6:]!='[DONE]'and json.loads(line[6:]).get('id')),None),'request_body_sha256':digest(payload),'request_body_reconstructed_from_frozen_code':True,'messages_sha256':digest(ev.messages(r)),'tools_sha256':digest(toollist),'input_token_sha256':token_hash(prompt),'actual_prompt_tokens':len(prompt),'effective_requested_cap':cap,'server_accepted_cap':'NOT_RECORDED_SERVER_INTERNAL; request hash and returned count verified','bounds':r['cap_bounds'],'output_tokens':len(built['output_token_ids']),'usage_completion_tokens':r['usage']['completion_tokens'],'eos_observed':r['eos_observed'],'cap_reached':len(built['output_token_ids'])>=cap,'finish_reason':built['server_finish_reason'],'stop_reason':built['server_stop_reason'],'raw_generated_slots':len(slots),'engine_calls':len(built['tool_calls']),'parser_accepted_slots':sum(s['parsed']is not None for s in slots),'host_admitted_slots':sum(x['host_admitted']for x in per_calls if x['turn']==turn),'executed_events':len(new),'tool_result_ids_before_generation':list(frozen),'state_digest_before_generation':r['state_digest'],'state_version':r['state_version'],'terminal_after_response':terminal,'remaining_model_calls':8-len(rs),'remaining_tool_attempts':6-attempts,'remaining_output_tokens':8192-tokens,'http_end_seconds':r['http_end_seconds'],'source_pointer':r['source_pointer']})
  if terminal=='UNKNOWN':terminal='MODEL_CALL_LIMIT'if len(rs)==8 else'TOKEN_LIMIT'if tokens>=8192 else'UNEXPLAINED'
  assert terminal==e['terminal_reason'];assert fx.events==e['events']and fx.snapshot()==e['final_state']and fx.version==e['final_state_version'];assert attempts==e['tool_attempts']and tokens==e['output_tokens']
  v=independent_verdict(t,fx.events,rs,final,fx.state,fx.version,terminal);reference=assess(t,fx.events,rs,final,fx.state,fx.version,terminal)
  for k in ['VERIFIED_WORKFLOW_SUCCESS','STATE_CORRECT','FINAL_ANSWER_CORRECT','CLAIMED_DONE_WITH_WRONG_STATE','first_unmet_obligation','unmet_obligations']:
   assert v[k]==reference[k]
   if v[k]!=e[k]:original_mismatches.append({'episode_id':e['episode_id'],'field':k,'reported':e[k],'recomputed':v[k]})
  diag=diagnosis(t,e,fx.events,rs,v);details.append({'episode_id':e['episode_id'],'kv':e['kv'],'family':e['family'],'first_unmet':v['first_unmet_obligation'],'terminal':terminal,**diag})
  last=rs[-1];lastslots=last['parsed_slots'];final_requested=any(not r['parsed_slots']for r in rs);slot6delivered=bool(last_admitted and last_admitted['slot'].get('event')and any(last_admitted['slot']['event']['event_id']in r['available_result_event_ids']for r in rs if r['turn']>last_admitted['request_turn']))
  row={'episode_id':e['episode_id'],'task_id':e['task_id'],'family':e['family'],'kv':e['kv'],'menu':e['menu'],'cap':e['cap'],'availability':e['availability'],'terminal':terminal,'first_unmet':v['first_unmet_obligation'],'model_requests':len(rs),'raw_generated_slots':allslots,'parser_accepted_slots':sum(x['parser_accepted']for x in per_calls),'host_attempts':attempts,'events':len(fx.events),'callable_successes':sum(x['status']=='SUCCESS'for x in fx.events),'content_side_effects':sum(x['state_before']!=x['state_after']for x in fx.events),'state_version_increments':fx.version,'output_tokens':tokens,'remaining_model_calls':8-len(rs),'remaining_tool_calls':6-attempts,'remaining_output_tokens':8192-tokens,'last_context_headroom_before_generation':28672-last['actual_prompt_tokens'],'remaining_episode_wall_from_recorded_end_seconds':900-e['wall_seconds'],'final_no_tool_response_observed':final_requested,'sixth_slot_name':last_admitted['slot']['parsed']['name']if last_admitted and last_admitted['slot']['parsed']else None,'sixth_slot_result_observed_in_next_generation':slot6delivered,'generation_after_sixth_slot':bool(last_admitted and any(r['turn']>last_admitted['request_turn']for r in rs)),'last_observed_result_event_ids':last['available_result_event_ids'],'final_state_version':fx.version,'last_validation':next((x for x in reversed(fx.events)if x['name']=='validate_state'),None),'unmet_all':v['unmet_obligations'],'source_pointer':e['source_pointer'],'evidence_kind':'STORED_TRACE_REPLAY'}
  for k,short in [('VERIFIED_WORKFLOW_SUCCESS','verified'),('STATE_CORRECT','state'),('FINAL_ANSWER_CORRECT','final'),('CLAIMED_DONE_WITH_WRONG_STATE','false_done')]:row['reported_'+short]=e[k];row['recomputed_'+short]=v[k]
  row['row_sha256']=digest(row);episodes.append(row);joint[(e['kv'],v['STATE_CORRECT'],v['FINAL_ANSWER_CORRECT'],v['VERIFIED_WORKFLOW_SUCCESS'])]+=1
  if terminal=='TOOL_CALL_LIMIT':
   blocked=[x for x in per_calls if not x['host_admitted']];six.append({'episode_id':e['episode_id'],'kv':e['kv'],'sixth_slot':last_admitted,'blocked_generated_slots':[{'turn':x['turn'],'call_index':x['call_index'],'parsed':x['parsed']}for x in blocked],'sixth_result_appended_to_messages':last_admitted['slot'].get('event')is not None,'sixth_result_observed_later':slot6delivered,'generation_after_sixth':row['generation_after_sixth_slot'],'final_opportunity_censored_by_same_response_overflow':not row['generation_after_sixth_slot'],'budget_remaining':{k:row[k]for k in row if k.startswith('remaining_')},'obligations_present':v['groups'],'stop_path':'episode_runner.py:50 pre-slot guard; :61/:64 break on terminal TOOL_CALL_LIMIT','source_pointer':e['source_pointer']})
  if e['kv']=='B16'and v['STATE_CORRECT']:
   reason='NO_FINAL_JSON; seventh validation call generated but not executed'if final is None and terminal=='TOOL_CALL_LIMIT'else'OTHER'
   state_rows.append({'episode_id':e['episode_id'],'task_id':e['task_id'],'menu':e['menu'],'cap':e['cap'],'state_correct':True,'final_correct':v['FINAL_ANSWER_CORRECT'],'reason':reason,'sixth_call':row['sixth_slot_name'],'post_sixth_generation':row['generation_after_sixth_slot'],'last_generated_calls':[s['parsed']for s in lastslots],'validation_events':len([x for x in fx.events if x['name']=='validate_state']),'remaining_model_calls':8-len(rs),'remaining_output_tokens':8192-tokens,'last_context_headroom':28672-last['actual_prompt_tokens'],'remaining_wall_seconds':900-e['wall_seconds'],'source_pointer':e['source_pointer']})
  for k in ('raw_sse_lines','sse_events'):pass
 assert len(ids_seen)==96
 groups=[]
 for kv,m,c in itertools.product(('B16','F4'),(8,32),(256,1024)):
  sub=[e for e in episodes if(e['kv'],e['menu'],e['cap'])==(kv,m,c)];assert len(sub)==12
  a={'kv':kv,'menu':m,'cap':c,'n':len(sub)}
  for metric in ('verified','state','final','false_done'):
   for prefix in ('reported','recomputed'):a[prefix+'_'+metric]=sum(x[prefix+'_'+metric]for x in sub)
  groups.append(a)
 lookup={(e['task_id'],e['kv'],e['menu'],e['cap']):e for e in ev.episodes};pairs=[]
 for tid,kv,m in itertools.product(sorted(ev.tasks),('B16','F4'),(8,32)):
  a,b=lookup[(tid,kv,m,256)],lookup[(tid,kv,m,1024)]
  tokenssame=[r['output_token_ids']for r in a['responses']]==[r['output_token_ids']for r in b['responses']];callssame=[[s['parsed']for s in r['parsed_slots']]for r in a['responses']]==[[s['parsed']for s in r['parsed_slots']]for r in b['responses']];eventssame=a['events']==b['events'];statusesame=all(a[k]==b[k]for k in ['VERIFIED_WORKFLOW_SUCCESS','STATE_CORRECT','FINAL_ANSWER_CORRECT'])
  category='ALL_OUTPUT_TOKENS_AND_TRAJECTORY_IDENTICAL'if tokenssame and eventssame else'SUCCESS_CHANGED'if a['VERIFIED_WORKFLOW_SUCCESS']!=b['VERIFIED_WORKFLOW_SUCCESS']else'GENERATION_CHANGED_SAME_EXECUTION'if eventssame else'STATE_OR_CALLS_CHANGED_SUCCESS_UNCHANGED'
  assert ev.messages(a['responses'][0])==ev.messages(b['responses'][0])and ev.ids(a['responses'][0]['prompt_ids_ref'])==ev.ids(b['responses'][0]['prompt_ids_ref'])
  pairs.append({'task_id':tid,'kv':kv,'menu':m,'initial_inputs_equal':True,'only_initial_payload_difference':'max_tokens 256 vs1024','category':category,'all_output_token_sequences_identical':tokenssame,'all_parsed_calls_identical':callssame,'all_events_identical':eventssame,'success_equal':a['VERIFIED_WORKFLOW_SUCCESS']==b['VERIFIED_WORKFLOW_SUCCESS'],'n_requests_cap256':a['model_calls'],'n_requests_cap1024':b['model_calls']})
 for tid,m,c in itertools.product(sorted(ev.tasks),(8,32),(256,1024)):
  a,b=lookup[(tid,'B16',m,c)],lookup[(tid,'F4',m,c)];assert ev.messages(a['responses'][0])==ev.messages(b['responses'][0])and ev.ids(a['responses'][0]['prompt_ids_ref'])==ev.ids(b['responses'][0]['prompt_ids_ref']);assert a['initial_surface_hash']==b['initial_surface_hash']
 hist={kv:{str(i):sum(e['kv']==kv and e['host_attempts']==i for e in episodes)for i in range(7)}for kv in ('B16','F4')};cross=collections.Counter((e['kv'],e['terminal'],e['first_unmet']or'none')for e in episodes)
 write_csv(output/'episode_ledger.csv',episodes);write_csv(output/'request_ledger.csv',requests);write_csv(output/'cap_pairs.csv',pairs);write_csv(output/'state_correct_without_final.csv',state_rows);write_csv(output/'cell_comparison.csv',groups)
 with(output/'call_ledger.jsonl').open('w')as f:
  for x in calls:f.write(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
 save(output/'tool_limit_cases.json',six);save(output/'obligation_diagnostics.json',details);save(output/'oracle_audit.json',goldrows)
 summary={'status':'PASS','episodes':96,'requests':len(requests),'call_slots':len(calls),'tool_attempt_histogram':hist,'groups':groups,'terminal_first_unmet':[{'kv':k[0],'terminal':k[1],'first_unmet':k[2],'n':v}for k,v in sorted(cross.items())],'state_final_verified_cross':[{'kv':k[0],'state':k[1],'final':k[2],'verified':k[3],'n':v}for k,v in joint.items()],'cap_pair_categories':dict(collections.Counter(p['category']for p in pairs)),'sse':dict(sse_meta),'score_mismatches':original_mismatches,'tool_limit_n':len(six),'sixth_validation_tool_limit_n':sum(x['sixth_slot']['slot'].get('parsed',{}).get('name')=='validate_state'for x in six if x['sixth_slot']['slot'].get('parsed')),'blocked_generated_slots':sum(not c['host_admitted']for c in calls),'malformed_admitted':sum(c['host_admitted']and not c['parser_accepted']for c in calls),'fresh_gpu_requests':0,'input_retokenization':'separate CPU tokenizer receipt; here exact stored IDs and request/history/hash replay','evidence_kind':'STORED_TRACE_REPLAY'}
 save(output/'summary.json',summary);print(json.dumps({k:v for k,v in summary.items()if k not in ('groups','terminal_first_unmet','state_final_verified_cross')},ensure_ascii=False))
 return summary

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args();run(a.output,Evidence())
if __name__=='__main__':main()
