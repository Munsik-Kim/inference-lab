"""Subprocess-only CPU guard. Original environment and other services are untouched."""
import builtins, socket
_original_import=builtins.__import__
def _guard(name,*args,**kwargs):
    if name.split('.')[0] in {'torch','transformers','vllm','cupy'}:
        raise RuntimeError('CPU_AUDIT_FORBIDDEN_IMPORT: '+name)
    return _original_import(name,*args,**kwargs)
builtins.__import__=_guard
def _no_network(*args,**kwargs):raise RuntimeError('CPU_AUDIT_NETWORK_FORBIDDEN')
socket.socket.connect=_no_network
socket.socket.connect_ex=_no_network
