"""Search for missed exact final objects without relaxing the original score."""
import argparse,json
from audit_baseline import Evidence,independent_oracle,save

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=__import__('pathlib').Path);a=p.parse_args()
 if a.output.exists():raise ValueError('fresh output file required')
 ev=Evidence();rows=[];candidates=[];keysets={}
 for e in ev.episodes:
  gold=independent_oracle(ev.tasks[e['task_id']]);expected={k:gold[k]for k in ('record_id','total_minor','source_version','status')};expected['validated']=True
  for r in e['responses']:
   for field in ('content','raw_text'):
    text=r.get(field)or''
    for pos,ch in enumerate(text):
     if ch!='{':continue
     try:obj,end=json.JSONDecoder().raw_decode(text[pos:])
     except ValueError:continue
     if type(obj)is dict and set(obj)==set(expected)and all(type(obj[k])is type(v)and obj[k]==v for k,v in expected.items()):candidates.append({'episode_id':e['episode_id'],'turn':r['turn'],'field':field,'offset':pos,'accepted_as_final':e['final']==obj,'has_tool_slots':bool(r['parsed_slots'])})
  if type(e['final'])is dict:
   keys=','.join(sorted(e['final']));keysets[keys]=keysets.get(keys,0)+1
  rows.append({'episode_id':e['episode_id'],'terminal':e['terminal_reason'],'strict_final_object':e['final'],'last_response_content':e['responses'][-1]['content'],'state_correct':e['STATE_CORRECT'],'final_correct':e['FINAL_ANSWER_CORRECT'],'false_done':e['CLAIMED_DONE_WITH_WRONG_STATE'],'source_of_claim':'MODEL_FINAL_CONTENT'if e['CLAIMED_DONE_WITH_WRONG_STATE']else None,'last_tool_validation':next((x['result']for x in reversed(e['events'])if x['name']=='validate_state'),None)})
 missed=[x for x in candidates if not x['accepted_as_final']];assert not missed
 save(a.output,{'status':'PASS','evidence_kind':'STORED_TRACE_DIAGNOSTIC; permissive search never changes original strict score','rows':rows,'exact_flat_final_candidates':candidates,'candidate_field_occurrences':len(candidates),'unique_response_candidates':len({(x['episode_id'],x['turn'])for x in candidates}),'unaccepted_exact_flat_final_candidates':missed,'observed_final_keysets':keysets,'scope':'Raw fields only; no guessed completion or new tool execution.','new_score_changes':0})
 print(json.dumps({'status':'PASS','unique_correct_final_responses':len({(x['episode_id'],x['turn'])for x in candidates}),'missed_exact_flat_finals':len(missed)}))
if __name__=='__main__':main()
