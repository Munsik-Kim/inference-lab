"""Render the Korean audit from recomputed ledgers; no original files changed."""
import csv,json,pathlib,collections
from audit_baseline import ROOT,load,save

def table(headers,rows):
 return '| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+''.join('| '+' | '.join(str(v).replace('|',' / ')for v in r)+' |\n'for r in rows)
def main():
 r=ROOT/'results/replay_r2';s=ROOT/'results/supplement_r1';summary=load(r/'summary.json');rows=list(csv.DictReader((r/'episode_ledger.csv').open()));state=list(csv.DictReader((r/'state_correct_without_final.csv').open()));qs=list(csv.DictReader((r/'request_ledger.csv').open()));six=load(r/'tool_limit_cases.json');subtypes=load(s/'obligation_subtypes.json');caps=load(s/'cap_statistics.json');bound=load(ROOT/'results/budget_boundary_tests.json');tokenizer=load(ROOT/'results/tokenizer_audit.json');time=load(s/'cache_time_audit.json')['timing'];events=load(s/'event_boundaries.json')
 findings=[]
 def finding(fid,question,observed,evidence,affected,impact,confidence,next_action,alternative='원자료로 분리할 수 없는 내부 원인은 미확정'):
  # Alternative text is always explicitly provided in Korean below.
  findings.append({'finding_id':fid,'question':question,'direct_observation':observed,'evidence':evidence,'tests':['STORED_TRACE_REPLAY all96','results/budget_boundary_tests.json']if fid in ['F02','F03']else['STORED_TRACE_REPLAY all96'],'affected_episode_ids':affected,'original_score_impact':impact,'alternative_explanation_or_limit':alternative,'confidence':confidence,'recommended_next_action':next_action})
 ptr=lambda p,fn,line:{'path':'evidence/source/kv_agent_bench/'+p+'.py','original_path':'src/kv_agent_bench/'+p+'.py','function':fn,'line':line}
 bstate=[x['episode_id']for x in rows if x['kv']=='B16'and x['recomputed_state']=='True'];allids=[x['episode_id']for x in rows];sourceids=[x['episode_id']for x in rows if x['first_unmet']=='source'];censored=[x['episode_id']for x in six if x['final_opportunity_censored_by_same_response_overflow']]
 finding('F01','B16 0/48이 조립·결과 전달·채점 계산 오류인가?','478개 SSE의 choice/index/id·token·content·호출을 별도 조립하고 535개 사건을 새 fixture에서 재실행했다. 모든 후속 messages/tools/request hash·관측·상태·원점수가 일치했다.',[ptr('vllm_client','StreamAssembly',8),ptr('episode_runner','run_episode',37),'results/replay_r2/summary.json'],allids,'동일 endpoint의 변경 0/96','TRACE_CONFIRMED','원점수 유지. 서버 내부 parser 구현 전체와 모델 내부 원인은 이번 CPU 감사로 확정하지 않는다.','저장되지 않은 서버 내부 sampling 설정은 따로 확인할 수 없다. 현재 기록의 n=1에서의 조립 검증이다.')
 finding('F02','6번째 호출 뒤 final 자체를 막았는가?','실제 runner 주입 테스트에서 6번째 validation 뒤 final이 허용된다. B16 state-correct12건은 helper timestamp3+read+calculate+write가6회이고, 다음 generation의 validation이7번째여서 미실행됐다. 12건 모두 6번째 write 결과를 받은 다음 생성 기회가 있었다.',[ptr('episode_runner','run_episode',50),ptr('episode_runner','run_episode',61),'results/replay_r2/state_correct_without_final.csv','results/budget_boundary_tests.json'],bstate,'원점수 변경0. 추가 도구·생성 허용 시 성공할 수는 미관측','POLICY_DEFINED','불필요한 helper 사용과6회 정책의 상호작용을 기록. 정책 변경은 별도 등록 대조가 필요하다.','그 다음 validation을 허용해도 정확한 final을 생성할지는 새 추론 없이는 모른다. 계약이6회 직후 무조건 종료한다고 쓰여 있지는 않다.')
 finding('F03','같은 응답에 초과 호출이 있으면 계속 final을 받을 수 있는가?','62 TOOL_CALL_LIMIT 중60건은6번째 결과 뒤 다음 generation이 있었고2건은 같은 응답의 초과 호출에서 즉시 종료했다. 6번째가 validation인 실제 사례는0건이다. 두 즉시 종료 사례는 아직 계산·write·validation이 없었다.',[ptr('episode_runner','run_episode',50),ptr('episode_runner','run_episode',61),'results/replay_r2/tool_limit_cases.json'],censored,'현재0→성공 변경을 입증할 기록 없음','CONTRACT_AMBIGUOUS','초과 slot을 만나면 전체 episode를 끝내는 정책을 다음 protocol에 명시. 이번에는 코드·점수 유지.','max tool attempts6은 명확하나 초과 응답 이후 final-only 기회를 별도 보장하는 문구는 없다. 이를 확정된 구현-계약 불일치로 단정하지 않는다.')
 finding('F04','first-unmet source48은 모두 잘못된 자료 선택인가?','B16 28건은 낮은version10/오래된event6/cutoff후4/취소·version우선8이다. F4 20건은 read없음10/낮은version4/cutoff후4/오래된event2이다. 존재하지 않는ID와 올바른 결과 미전달 사례는 이48건에서 발견되지 않았다.',[ptr('fixture_generator','oracle',13),ptr('scorer','assess',20),'results/supplement_r1/obligation_subtypes.json'],sourceids,'원점수 변경0','TRACE_CONFIRMED','짧은 동일 사실 입력 또는 공통 gold-history 진단을 별도 계획으로 제안한다.','최초 label은 DAG의 정해진 우선순위다. 모델 내부 이해 실패의 단일 인과 원인까지 증명하지 않는다.')
 finding('F05','공개 validator가 정답을 보장한다고 오해하게 설명됐는가?','모델용 설명에 task correctness를 확인하지 않는다고 명시돼 있다. B16 DEV-B00은 version2/348142를 실제 저장하고 public valid:true를 받았지만 gold는 version3/253559이다. 최종 validated:true는 모델 자신의 답이다.',[ptr('fixture_generator','tools',55),ptr('tools','Fixture.execute',36),'results/replay_r2/obligation_diagnostics.json'],[x['episode_id']for x in rows if x['kv']=='B16'and x['task_id']=='DEV-B00'],'false-done 원점수 유지','TRACE_CONFIRMED','schema validation과 독립 업무 정답의 차이를 그대로 설명한다.','모델이 설명을 어떻게 해석했는지는 관측하지 못했다. hidden gold를 validator에 추가하지 않는다.')
 finding('F06','F4 final-correct10 중4건이 완주하지 못한 이유는?','A00/menu32 두cap은 write 뒤 validation을 호출하지 않았다. A02/menu32 두cap은 초기 version0의 false validation만 있고 calculate+write를 같은 응답에서 생성해 계산 결과도 사전 관측하지 않았다.',[ptr('scorer','assess',23),ptr('scorer','assess',27),'results/supplement_r1/final_correct_not_verified.json'],[x['episode_id']for x in rows if x['kv']=='F4'and x['recomputed_final']=='True'and x['recomputed_verified']=='False'],'원점수 변경0','TRACE_CONFIRMED','파일 정답·최종 JSON 정답·관측을 갖춘 업무 완주를 분리해서 유지한다.','first-unmet validation만 보면 A02의 별도 관측 위반이 가려진다. endpoint 자체는 이미 이를 검사한다.')
 finding('F07','cap 증가가 실제 적용됐는가?','478개 outgoing request hash가 동결 코드를 이용한 body와 일치한다. cap256/1024가 실제 요청됐다. 47/48pair의 output IDs와 도구 사건이 같다. F4 DEV-C00/menu32만256에서 length/부분 slot,1024에서282token으로 달랐으며 양쪽 업무 실패였다.',[ptr('vllm_client','request_cap',66),ptr('episode_runner','run_episode',20),'results/replay_r2/cap_pairs.csv','results/supplement_r1/cap_statistics.json'],allids,'원점수 변경0','TRACE_CONFIRMED','cap 효과 없음은 이번 완주 결과로 한정한다.','서버 내부 normalized sampling cap은 직접 기록되지 않았다. 평균 길이로 모든 응답이256미만이었다고 판단하면 틀린다.')
 finding('F08','9개 F4 시도-사건 차이는 누락된 실행인가?','4개는 유효 JSON이지만 function키 대신 name키를 요구하는 도구 wrapper 불일치,2개는 닫히지 않은ID문자열,2개는 extra closing brace,1개는256token에서 끊긴 timestamp이다. 모두 host 시도는 소모했지만 accepted 호출이 아니므로 callable이 실행되지 않았다.',[ptr('observations','ordered_slots',5),ptr('episode_runner','run_episode',52),'results/supplement_r1/slot_syntax.json'],sorted({x['episode_id']for x in load(s/'slot_syntax.json')if x['host_admitted']and not x['engine_parser_accepted']}),'원점수 변경0','TRACE_CONFIRMED','JSON 문법·tool envelope·인자·예산 분모를 분리해 유지한다.','원 parser를 관대하게 바꾼 결과는 원점수가 아니다. 신규 실행·JSON repair를 하지 않았다.')
 finding('F09','P1의 수정 전후 소스가 섞였는가?','P1 96개가 동일 execution source SHA를 사용하며35개 freeze 파일이 현물과 일치한다. amendment01~08은 P1 전 freeze에 들어 있다. P0의 다른 source를 P1 분모에 섞지 않았다.', ['results/p1_source_identity.json','results/supplement_r1/amendment_audit.json','evidence/diffs/'],allids,'현재 비교를 무효화할 혼합 발견0','TRACE_CONFIRMED','P0의 서로 다른 원형과 amendment를 그대로 보존한다.','문서별 독립 서명 시각은 없다. mtime 대신 freeze 생성시각·포함 hash·attempt/source 연결을 근거로 삼았다.')
 finding('F10','F4의 성공3과제는 오류 회복인가?','B00/B02는 정답source부터 선택한 정상 경로다. D02는 초기 validation=false 뒤 정상 계산/write와 최신 validation=true를 관측해 완주했다. parser 오류 후 host feedback으로 회복한 사례는 아니다. 두cap의 같은3과제 반복이다.',['results/supplement_r1/f4_success_paths.json','results/supplement_r1/first_divergences.json'],[x['episode_id']for x in rows if x['recomputed_verified']=='True'],'원점수 변경0','TRACE_CONFIRMED','첫 공통 입력에서의 행동 분기와 그 후 서로 다른 history를 분리한다.','메뉴8/32 비교는 처음부터 tools가 다르다. 같은 fixture 상태를 같은 전체 정책 입력이라 부르지 않는다.')
 finding('F11','KV fallback·자원 집계가 기준선 실패를 설명하는가?','36층 metadata와 capacity×bytes/token이 실제 고유 pool과 일치한다. F4는 packed NVFP4+block scale이며 FA2 reader다. worker1084.509s와 attempt합1081.577s의2.933s차이는 바깥 freeze/tokenizer/요약 범위와 대응한다.',['results/supplement_r1/cache_time_audit.json','evidence/source_static/kernel_check.py'],'ALL_P1','품질 점수 변경0','CODE_CONFIRMED','기존 저장 dtype·비용 정의를 유지한다.','이 CPU 감사는 캐시·GPU kernel을 다시 실행하지 않았다. XQA 미선택 이유와 전체 model logits 유한성은 미확인 상태를 유지한다.')
 finding('F12','원자료만으로 남은 원인을 어디까지 말할 수 있는가?','기록에서 자료·인자 선택, 보조 호출 소비, 검증 없는 완료가 확인된다. 새로운 final을 가정하거나 tool budget을 완화해 성공 수를 추가하지 않았다.',['results/replay_r2/episode_ledger.csv','results/replay_r2/request_ledger.csv'],allids,'동일 규약 점수 변경0; revised-policy counterfactual 성공수 UNKNOWN','UNOBSERVABLE','새 실험이 필요하면 입력 길이/관측 진단과 정책 대조를 별도로 사전 등록하고 승인받는다.','이번 자료만으로 KV 수치 오차·장문 이해·도구 계획의 내부 기여를 인과 분해할 수 없다.')
 finding('F13','timeout이 발생한 요청의 비용 counter는 정확한가?','주입한 TimeoutError 검사에서는 request callback을1회 호출했지만 model_calls=len(responses)는0을 반환한다. 이는 반환 응답 수와 시도 요청 수를 같은 필드로 쓰는 비용 기록의 공백이다. 실제 P1의96개에는 이런 예외가 없어478개 요청·점수에는 영향이 없다.',[ptr('episode_runner','run_episode',27),ptr('episode_runner','run_episode',78),'results/budget_boundary_tests.json'],[],'실제 P1 점수·요청 수 영향0; 예외 시도 비용만 합성 검사에서 재현','CODE_CONFIRMED','다음 버전에서 request_attempts와 returned_responses를 별도로 기록하는 최소 CPU 수정·회귀검사를 제안한다. 이번 원코드는 수정하지 않는다.','새 모델 timeout을 발생시킨 것이 아니다. 원 P1에 없던 실행 장애를 B16 실패 원인으로 세지 않는다.')
 findings[-1]['tests']=['AuditBoundaries.test_request_timeout_distinct + callback invocation counter']
 save(ROOT/'findings.json',findings)
 cells=table(['KV','메뉴','cap','완주 원/재계산','상태 원/재계산','최종답 원/재계산','잘못된 완료 주장 원/재계산'],[[x['kv'],x['menu'],x['cap']]+[f"{x['reported_'+k]}/{x['recomputed_'+k]}"for k in ('verified','state','final','false_done')]for x in summary['groups']])
 hist=table(['KV']+[str(i)+'회'for i in range(7)],[[kv]+[summary['tool_attempt_histogram'][kv][str(i)]for i in range(7)]for kv in ('B16','F4')])
 crosskeys=['source','calculation','write','validation','none'];cross=table(['KV','종료']+crosskeys,[[kv,term]+[next((x['n']for x in summary['terminal_first_unmet']if(x['kv'],x['terminal'],x['first_unmet'])==(kv,term,k)),0)for k in crosskeys]for kv in ('B16','F4')for term in ('TOOL_CALL_LIMIT','FINAL','PARSE_STOP')])
 st=table(['task','메뉴','cap','6번째→다음 생성','남은 모델 요청','남은 출력token','종료 시 남은wall초'],[[x['task_id'],x['menu'],x['cap'],'write→7번째 validation 미실행',x['remaining_model_calls'],x['remaining_output_tokens'],f"{float(x['remaining_wall_seconds']):.3f}"]for x in state])
 stages=table(['KV','생성slot','engine call','파서 accepted','host시도','callable실행','미실행parse','한도초과slot'],[[x[k]for k in ('kv','generated_slots','engine_call_objects','parser_accepted','host_admitted','schema_registry_pass_and_callable_executed','malformed_admitted_no_event','budget_blocked_slots')]for x in events])
 captable=table(['KV','cap','요청','p50','p95(nearest rank)','최대','length종료','cap도달'],[[x[k]for k in ('kv','cap','requests','p50','p95_nearest_rank','max','finish_length','cap_reached')]for x in caps])
 obligation=table(['최초 미충족','KV','수','세부 유형'],[[x['first_unmet'],x['kv'],x['n'],x['subtype_counts']]for x in subtypes])
 joint=table(['KV','상태 정답','최종답 정답','완주','수'],[[x[k]for k in ('kv','state','final','verified','n')]for x in summary['state_final_verified_cross']])
 ftable=table(['ID','판정','원점수 영향'],[[x['finding_id'],x['confidence'],x['original_score_impact']]for x in findings])
 success=table(['과제(각 두cap)','B16/메뉴32','F4/메뉴8','F4/메뉴32','관측된 분기'],[['DEV-B00','잘못된version2→348142','같은 잘못된version2','version3→253559로 완주','공통 첫입력에서 helper 대 정답 read'],['DEV-B02','service+여러read 뒤 잘못된price/도구한도','여러read 뒤version2값으로 계산','version3값으로 직접 계산·완주','공통 첫입력에서 helper 대 정답 read'],['DEV-D02','timestamp3회 뒤7번째validation 차단','보조call·추가read로 계산 전 한도','초기false검증 뒤 최신true검증·완주','공통 첫입력에서 timestamp 대 read+검증']])
 report=f'''# Case016 — B16 기준선 실패 원자료·실행기 감사

새 GPU 추론·모델 로드·서버 호출 **0회**. 기존 96개 실측 기록의 CPU 감사이며 원점수는 변경하지 않았습니다.

B16은 BF16 KV 캐시 기준선이고 F4는 NVFP4 KV 캐시 조건입니다. 상태 정답은 실제 저장 내용이 맞는지, 최종 답 정답은 모델의 마지막 JSON 답이 맞는지입니다. 업무 완주는 두 조건에 더해 자료 확인·계산·검증의 순서와 관측까지 충족해야 합니다.

**핵심 판정:** B16 완주0/48을 뒤집는 SSE 조립·결과 전달·동일 endpoint 채점 오류는 발견하지 못했습니다. 도구6회 사용 뒤 final을 무조건 차단하는 구현도 아닙니다. 상태 정답12건은 시간 문자열의 형식 확인(timestamp) 3회 때문에 write가6번째가 됐고, 이후 모델이 생성한7번째 validation은 등록 한도 때문에 실행되지 않았습니다. 다른 B16 경로에는 잘못된 자료·금액 인자 선택이 남습니다. 따라서 도구 계획과6회 정책의 상호작용, 내용 선택 오류를 구분해서 기록합니다.

[비교 계약](#identity) · [전체 점수](#scores) · [한도와 final](#budget) · [자료와 관측](#source) · [cap와 성공 경로](#caps) · [KV와 시간](#cache) · [판정·다음 단계](#decision) · [재현](#reproduce)

<a id="identity"></a>
## 비교 계약과 원형 보존

Git base는 `0c86afa4728cbf901f6c3df64802810db6581a00`, P1 source 묶음 SHA256은 `ab8463e9bfde41564e44a863bc1159dfecf26cada54a7fdceea5ebec127e53ee`, 모델 revision은 `cdbee75f17c01a7cc42f958dc650907174af0554`입니다. 서로 다른 객체입니다.

96개 키는12 DEV×2 KV×2메뉴×2cap이며 누락·중복·대체 attempt는0입니다. 전부 같은 실행 source를 가리키고35개 freeze 파일은 현물과 일치합니다. 원본 case 밖에만 새 파일을 썼습니다. [원형 source manifest](provenance/source_manifest.json), [amendment 감사](results/supplement_r1/amendment_audit.json), [실제 diff](evidence/diffs/)를 보존합니다.

amendment01/02/04/05는 startup·새 환경 compiler/link 경로,03은 local tool-history 정규화와 토큰 identity,06은 P0 취소·raw slot 순서,07은 P0 abort log,08은 strict constraint OFF 명시입니다. 모두 P1 전 동결집합에 포함됩니다. P0의 다른 source 결과를96개에 섞지 않았습니다. 문서별 별도 서명 시각은 없으며 freeze·attempt·source hash 연결로 확인했고 mtime을 동결 인증으로 쓰지 않았습니다. 인접한10개 동결 전이의 실제 코드 diff도 [별도 장부](results/adjacent_source_deltas.json)에 연결했습니다.

24개 고유 초기 입력을 포함한 **478개 전체 요청을 CPU tokenizer로 재인코딩**했고 실제 서버 IDs·해시와 일치했습니다. 출력 IDs의 원문 decode도478/478 일치합니다. 초기8192token과 근거 위치3600/5500/7350, 메뉴8/32의 같은 사실·위치, 내용과 source ID 연결을 확인했습니다. direct tokenizers/Jinja만 사용했고 Torch·Transformers를 import하지 않았습니다. 새 EVAL 데이터는 열지 않았습니다. DEV12는 동결된 generator의 원 seed로 재구성하여 전96개 canonical hash·실제 prompt 내용과 대조했습니다. EVAL 포함 원 파일은 보존 hash만 확인했습니다.

<a id="scores"></a>
## 1. 8개 셀의 원점수 / 독립 재계산

각 칸의 두 수는 원/재계산이고 분모는 각각12개 조건입니다. final은5필드의 엄격한 최종 JSON 정답, false-done은 모델 최종 JSON의 validated:true이면서 상태가 틀린 경우입니다. 도구 valid:true를 모델의 주장으로 대신 세지 않습니다.

{cells}

### 호출 연결과 실제 실행 경계

{stages}

모든535개 callable 사건은 schema·registry를 통과한 실제 실행이고 거절 사건은0입니다. B16의284시도도 모두 callable 실행입니다. F4의9개 차이는: `function`/`name` wrapper키 불일치4, 닫히지 않은ID문자열2, extra brace2, cap에서 끊긴timestamp1입니다. 유효 JSON과 도구 호출 형식을 구분합니다. 호스트 한도 때문에 실행되지 않은70개 완성 호출도 [call 장부](results/replay_r2/call_ledger.jsonl)에 남겼습니다.

별도 assembler는 choice/index/id를 사용했습니다. 실제 모든 choice index는0이고 id충돌·중복 덧붙임으로 인한 불일치는0입니다. role-only478개와 DONE478개는 호출로 세지 않았습니다. 후속 messages의 assistant call ID·도구 result role/content·관측 ID를 재구성해 실제 다음 요청과 일치함을 확인했습니다. 같은 응답의 후행 호출은 선행 결과를 사전 관측한 것으로 처리하지 않았습니다.

<a id="budget"></a>
## 2. 도구 한도와 최초 미충족

{hist}

{cross}

62개 한도 종료 모두6회 시도를 사용했습니다. 그 중60개는6번째 결과 뒤 추가 generation이 있었고,2개(F4 DEV-D01/menu8의 두cap)는 같은 응답의7번째 이후 slot에서 종료했습니다. 이2개는 계산·write·validation이 아직 없었으며 실제6번째가 validation인 한도 종료 사례는0건입니다. [62건 전체의6번째 인자/반환/상태/남은 예산](results/replay_r2/tool_limit_cases.json)을 포함합니다.

실제 runner에 mock generator를 주입한 CPU 검사에서 정답4call+5generation,6번째 validation 뒤 final, write→validate에 남은slot1/2,7번째 call의 미실행, model/token/context/deadline/timeout 경계가 확인됐습니다. 거절된 이름·schema도1시도, malformed slot도1시도를 쓰지만 후자는 도구 사건이 없습니다. 모든 주입 응답은 **SYNTHETIC_CONTRACT_TEST**이며 실제 회복 관측이 아닙니다.

6회까지 사용하고 final-only 답을 낼 수 있다는 구현은 확인했습니다. 다만 초과 call을 포함한 응답 뒤 final-only 기회를 새로 보장하는지는 protocol이 명시하지 않아 이 경계는 **CONTRACT_AMBIGUOUS**입니다. 현재 원점수를 뒤집는 IMPLEMENTATION_CONTRACT_MISMATCH로 단정하지 않습니다.

## 3. B16 상태 정답12건 전체

{st}

12건 모두 final JSON 자체가 없었습니다. final의 ID·금액을 잘못 적은 사례가 아닙니다. 6번째 write 결과를 전달한 뒤 generation5회째에7번째 validation을 생성했고 한도에 걸렸습니다. 생성 요청3회와 출력token 약7895~7900, 약889~891초가 남았지만 도구 예산은0이었습니다. 해당 validation이나 다음 final을 허용했을 때 성공했을 수는 기록에 없으므로 **unknown**입니다.

현재 scorer는 final JSON의 key집합과 type을 엄격히 검사합니다. bool을1로, 숫자를문자열로 대체하면 실패하고 extra key·중첩 answer object·여분 prose도 허용하지 않습니다. 이는 원 요청의 exactly/only JSON과 대응합니다. 12건에서 계약에 맞는 final을 추출기가 놓친 증거는 없었습니다.

### STATE / FINAL / VERIFIED 교차표

{joint}

F4에서 final이 맞지만 미완주인4건은 A00/menu32의 두cap(검증 호출없음), A02/menu32의 두cap(초기 false validation만 있고 계산과write를 같은 응답에서 만들어 계산 결과도 미관측)입니다. 파일과 최종 답이 맞더라도 요구된 최신 검증·관측 경로는 충족하지 않았습니다.

<a id="source"></a>
## 4. 자료·금액·관측 규약

{obligation}

DEV12의 공개 rule/cutoff/source/version/arrival/event/cancel을 별도 정렬·정수 divmod 계산으로 평가해 원 oracle12/12와 대조했습니다. 실제 금액 도구는 받은 인자 그대로 계산하고 저장기는 받은 값 그대로 저장했습니다. read는 원문 과제에서 명시된 절차이므로 숨은 재조회 의무가 아닙니다. 초기 사실은 generation0부터 가용하며 이를 못 받았다는 label을 추가하지 않았습니다.

대표 DEV-B00에서 B16은 cutoff 전에 도착한 최고version3 대신version2를 골랐습니다. 개수33·한 개 가격11105·할인5%로348142를 계산·저장했습니다. 올바른version3 가격8088이면253559입니다. validator 설명은 “public field types and nonnegative values; does not check task correctness”이고 실제 반환도 그 범위입니다. 그러므로 valid:true와 독립 업무 정답은 서로 다릅니다. 이외에도 최초 label이calculation/write/validation인 경로를 모두 표와 episode pointer에 연결했습니다.

first-unmet는 정해진 DAG 우선순위이며 내부 원인을 하나로 확정하지 않습니다. 예를 들어 A02의 첫label validation은 별도 계산-저장 관측 위반을 가리므로, 중첩 진단도 따로 남깁니다.

<a id="caps"></a>
## 5. cap 효과와 F4 성공의 실제 분기

{captable}

47/48 cap pair는 전체 output IDs·도구 사건까지 같았습니다. F4 DEV-C00/menu32만256에서6번째timestamp의 미완성 JSON/length,1024에서282token의 완성 호출로 달랐습니다. 두 조건 모두 다음 도구 한도로 실패하여 완주 변화는0입니다. 요청 cap은 request hash와 payload로 확인했으나 서버 내부 normalized sampling cap은 별도 필드로 기록되지 않아 NOT_RECORDED입니다. 전체478개에서 usage token과 반환IDs 수는 일치합니다.

{success}

B16/menu32 대 F4/menu32는 같은 초기 전체 입력에서 generation0의 첫 행동부터 다릅니다. F4/menu8 대menu32는 처음부터 도구 메뉴가 달라 같은 전체 정책 입력이 아닙니다. 업무 관측·fixture가 같다는 사실과 구분합니다. 이후 history가 갈라진 turn을 강제 정렬하지 않았습니다. B00/B02는 처음부터 잘못된 선택을 피한 경로이고, D02는 조기 검증false 후 최신 검증true로 완주했습니다. 어느 것도 parser 오류 뒤 새 host feedback을 받아 회복한 사례는 아닙니다.

<a id="cache"></a>
## 6. P0 저장·작은 decoder·시간의 재대조

B16/F8/F4의 capacity×bytes/token은 각각4293918720/4293918720/4294508544B와 일치합니다. 36층·고유storage1개와 scale의 불변을 확인했으며 같은 storage view를 중복 계수하지 않았습니다. F4는 packed data+block scale이고 FA2가 이를 읽은 기록이며 BF16 cache fallback이 아닙니다. XQA 미선택 이유는 기록에 없어 추정하지 않았습니다.

작은 kernel code는 FlashInfer가 별도 empty output에 쓴 dequantized 결과와, 같은 압축 cache에서 LUT·unpack·scale로 독립 계산한 새 tensor를 비교했습니다. 같은 tensor/view끼리 비교한 코드는 아닙니다. 다만 Qwen shape/head128/GQA4·길이96·NHD/HND의 작은 검사이며 전체 attention/모델 logits의 독립 유한성 검사로 확대하지 않습니다. 이번에는 해당 GPU 검사를 재실행하지 않았습니다.

합성 timeout 경계에서 별도 비용 기록 공백도 확인했습니다. request callback은1회 실행됐지만 원 model_calls는 반환 응답 수인0을 기록합니다(F13). 실제 P1에는 해당 예외가 없어478개 요청이나 원점수에 영향은 없습니다. 시도/반환 응답을 나눠 기록하는 다음 버전의 최소 CPU 보완을 제안할 뿐 이번 원 runner는 수정하지 않았습니다.

P1 worker={time['p1_worker_seconds']:.9f}s, 두 attempt 합={time['attempt_sum_seconds']:.9f}s, 차이={time['difference_seconds']:.9f}s입니다. worker는 freeze·tokenizer·준비부터 시작하며 server attempt와 요약/I/O의 경계가 다릅니다. 계측 sample 기준 첫 attempt 전{time['before_first_attempt_seconds']:.6f}s, 사이{time['between_attempt_timer_samples_seconds']:.6f}s, 마지막 이후{time['after_last_attempt_seconds']:.6f}s가 차이와 대응합니다. GPU busy나 serving speedup으로 재해석하지 않습니다.

<a id="decision"></a>
## 7. 발견사항·원점수 영향·다음 행동

{ftable}

[findings.json](findings.json)에 질문·직접 관측·원 파일/함수/line·test·영향 episode·대안 설명·확신 수준을 제공합니다. 동일 endpoint 재계산의 점수 변경은0/96입니다. 새로운 tool/final 기회가 필요한 revised-policy counterfactual은 성공 수를 만들지 않고 UNKNOWN으로 둡니다.

지금 권하는 것은 원 runner를 즉석에서 수정하는 일이 아닙니다. 다음 실험을 승인한다면6회/초과slot 종료 정책을 먼저 명시하고, 보조 호출 소비와 final 기회에 대한 별도 정책 대조를 등록할 수 있습니다. 자료·금액 선택 문제는 짧은 동일 사실 입력 또는 공통 gold-history 진단으로 따로 확인할 수 있습니다. 둘을 함께 바꿔 성공률을 올린 뒤 원인을 하나로 설명하면 안 됩니다. 이번에는 수정·추론·실제 회복 시험을 하지 않았습니다.

<a id="reproduce"></a>
## 재현·검사·제출 범위

기존 사전34종 중33종과 사후3종을 원 expectation 그대로 재실행했습니다. EVAL48을 생성하는1종은 이번 금지 범위 때문에 NOT_RUN_SCOPE로 분리했습니다. 신규 경계검사는15종 PASS이며 반복 실행은 새 고유검사로 더하지 않았습니다. 저장96개 replay는 STORED_TRACE_REPLAY, 모의 생성은 SYNTHETIC_CONTRACT_TEST입니다. 이번 감사 구현의 copy 함수 이름 충돌, wall label/line pointer 수정과 포장 검사기의 자기 문자열 일치는 logs에 남겼고 원실험 변경은0입니다.

[CPU 재현](REPRODUCE.ko.md), [전체96개 장부](results/replay_r2/episode_ledger.csv), [478요청](results/replay_r2/request_ledger.csv), [614slot](results/replay_r2/call_ledger.jsonl), [원형 hash](provenance/source_manifest.json), [전송본 범위](bundle_coverage.json)를 확인합니다. ZIP은 모든96개 endpoint replay와478개 raw SSE의 lossless 재조립에 필요한 dedup 증거를 포함합니다. 전체 원본 episode JSON의 byte-identical 사본·경과시간 SSE 메타데이터·tokenizer 모델 파일·weights·KV·환경은 제외합니다. 원파일 hash와 JSON pointer를 유지했고 선택한 원 fields를 lossless로 보존했습니다. scalar replay는 모델 생성 자체의 재현이 아닙니다.

Codex 보조로 구현·별도 CPU 계산을 수행했습니다. 사람의 독립 심사나 외부 GPU 재현으로 표시하지 않습니다. 원 Case016 보고서·측정·freeze는 그대로 보존했습니다. Git stage/commit/push/PR/Pages와 환경 설치·프로세스 종료는0회입니다.
'''
 (ROOT/'REPORT.ko.md').write_text(report)
 first='''Case016 B16 기준선 CPU 감사 — 먼저 읽기\n\n새 GPU 추론/모델 로드/서버 호출: 0회. 원 runner/parser/scorer/task/protocol/96개 점수는 수정하지 않았습니다.\n\n1. B16 완주0/48, 상태12/48, 최종답0/48과 F4 완주6/48을 원 SSE·사건·상태에서 재계산했고 불일치는0입니다.\n2. B16 상태 정답12건은 timestamp3회+read+calculate+write로6회를 쓰고, 다음 generation의7번째 validation이 실행되지 않았습니다. final JSON이 없으며 잘못된 final의 내용으로 분류하면 부정확합니다.\n3. 6번째validation 뒤 final-only 응답은 실제 runner CPU 주입 검사에서 허용됩니다. 따라서 6회를 쓰면 final까지 무조건 막는 버그는 확인되지 않았습니다.\n4. B16 first-unmet source28건에는 낮은version10/오래된event6/cutoff후4/취소·version우선8이 확인됐습니다. 도구 한도만 바꿔 모두 고쳐진다는 근거는 없습니다.\n5. cap48쌍 중47쌍은 출력 IDs·도구 궤적 동일. 1쌍은256에서 실제 length 중단됐지만 양쪽 모두 실패했습니다.\n6. 합성 timeout에서 시도1/반환응답counter0의 비용 기록 공백도 확인했으나 실제 P1에는 해당 예외가 없어 점수·요청 수 영향은0입니다.
7. 기존 CPU33+3, 신규15종 PASS. EVAL을 생성하는 과거1종은 금지 범위로 미실행했습니다. 새 모델 회복 결과는 없습니다.\n\nREPORT.ko.md, findings.json, REPRODUCE.ko.md를 순서대로 읽으면 됩니다. 원 자료는 건드리지 않았고 모델/환경/전체KV/대형profile은 검토 ZIP에 없습니다.\n'''
 (ROOT/'READ_FIRST.ko.txt').write_text(first)
 print(json.dumps({'report':'REPORT.ko.md','findings':len(findings),'state_correct_cases':len(state),'raw_replay_score_changes':len(summary['score_mismatches'])},ensure_ascii=False))
if __name__=='__main__':main()
