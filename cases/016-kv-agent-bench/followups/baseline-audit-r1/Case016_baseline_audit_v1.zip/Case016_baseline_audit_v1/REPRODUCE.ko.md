# 모델 없이 감사 결과를 재계산하기

새 검토 ZIP을 푼 폴더에서 실행합니다. 기본 검산에는 Python 표준 라이브러리만 필요하며 설치·모델·서버가 필요하지 않습니다. 출력은 검토 폴더 밖의 새 경로여야 합니다.

```bash
CASE016_AUDIT_OUT="$(mktemp -d /tmp/case016-baseline-check.XXXXXX)"
CUDA_VISIBLE_DEVICES='' HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src:evidence/source \
python3 -B src/verify.py --output "$CASE016_AUDIT_OUT/check"
```

실제로 수행하는 일은 다음과 같습니다.

1. `MANIFEST.json`의 모든 선택 파일 크기·SHA256을 대조합니다.
2. 478개 SSE를 lossless dedup 저장에서 복원하여 choice/index/id·token·content를 조립합니다.
3. 초기 DEV12 fixture에서96개 기록을 재적용하고 요청 body/hash·관측·상태·예산·endpoint를 별도 계산합니다.
4. 원점수를 정답으로 삼지 않고 별도 oracle·endpoint로 계산한 뒤 원점수와 대조합니다. 전 장부·paired 표를 포함된 결과와 byte 단위 대조합니다.
5. 과거33+3종과 신규15종의 CPU 검사를 실행합니다. EVAL48을 생성하는 과거1종은 금지 범위로 NOT_RUN_SCOPE입니다. 합성 응답은 측정 성능에 합산하지 않습니다.
6. cap·source·성공 경로·최종 답 추출 진단과 보고서 표를 대조합니다.

`src/sitecustomize.py`는 이 subprocess의 Torch/Transformers/vLLM import와 socket 연결을 거절합니다. 부모 환경이나 다른 서비스는 바꾸지 않습니다. 정상 검산에서 신규 GPU 요청은0입니다.

원 evidence의 `episodes.compact.json`은 전체 원본 episode 파일의 byte-identical 사본이 아닙니다. 필요한 원 fields·raw text·output IDs·상태/사건은 보존하고, 반복 messages와 token 배열을 content hash/prefix 참조로 중복 제거했습니다. `raw_sse_pool.json`은 반복 prompt 배열만 참조로 저장하며 원 line을 정확히 복원하고 원 stream hash를 대조합니다. 모든96개 endpoint와478개 raw SSE를 검산할 수 있습니다. 원 source file hash·JSON path·선택 excerpt hash를 함께 제공합니다.

실제 tokenizer 재인코딩은 별도의 로컬 CPU 검사였습니다. 기록은 [tokenizer_audit.json](results/tokenizer_audit.json)에 있습니다. 등록된 `tokenizer.json`·`tokenizer_config.json`과 기존 tokenizers/Jinja2가 있는 환경에서만 다음 선택적 명령을 쓸 수 있습니다.

```bash
CUDA_VISIBLE_DEVICES='' HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src:evidence/source \
"$CASE016_TOKENIZER_CPU_PYTHON" -B src/tokenizer_audit.py \
  --snapshot "$CASE016_REGISTERED_TOKENIZER_DIR" \
  --output "$CASE016_AUDIT_OUT/new-tokenizer-audit.json"
```

이 명령은 로컬의 두 tokenizer 파일만 읽으며 모델을 로드하지 않습니다. tokenizer 파일은 전송 ZIP에 포함하지 않았습니다. 기본 stdlib 검산이 tokenizer 재실행 또는 GPU 추론 재현을 했다고 표시하지 않습니다.

새 원자료를 수집하거나 원 Case016을 수정하는 진입점은 제공하지 않습니다. `extract_evidence.py`·`collect_sse.py`·`collect_metadata.py`는 이번 로컬 선별 과정의 기록용 코드이며 기본 검산에 필요하지 않습니다. 과거 GPU 관련 소스는 정적 검토 근거로만 들어 있고 실행하지 않습니다. 원 실험·미실행 항목·원점수는 [보고서](REPORT.ko.md), [전송 범위](bundle_coverage.json), [발견 장부](findings.json)를 참고합니다.
