# Case014 unified publication v1

[한국어](cases/014-quantization-compensation/README.ko.md) · [English](cases/014-quantization-compensation/README.md) · [CPU reproduction](cases/014-quantization-compensation/REPRODUCE.md)

This archive includes the Case014 source/result tree once. Original stage manifests and restored-view mapping are included. Model/K/INT4 weights/large activations/logits/text/tokens and the three old ZIPs are excluded. Full portfolio build needs the complete repository.
