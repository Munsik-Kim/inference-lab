# Local review: Case 013 tool-contract repair

Start with [Korean report](records/REPORT_KO.md) or [English report](records/REPORT.md).

Model-free replay after extraction, from this directory:

```bash
python3 -B code/analyze.py --result records --inputs records/inputs --output /tmp/tool-repair-review-audit-new --skip-external-preservation
python3 -B -m unittest discover -s code -p 'test_*.py' -v
```

The skip flag does not certify external models/cases; the original preservation receipt records the local check. Models, quantized weights, environments and full logits are excluded. Runtime hashes before redaction are external identities; exported bytes have a separate manifest. See the code guide for actual GPU prerequisites. This is a local review bundle, not a model download or remote publication.
